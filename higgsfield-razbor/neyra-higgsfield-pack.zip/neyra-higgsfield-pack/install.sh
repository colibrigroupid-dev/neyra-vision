#!/bin/sh
# Установка пакета в папку скилов Claude Code.
# Ничего не скачивает и не запускает из сети. Только копирует папки из ./skills.
#
#   sh install.sh              поставить, существующие скилы не трогать
#   sh install.sh --force      заменить существующие (старая копия уходит в соседнюю папку skills-backup-<время>)
#   sh install.sh --dry-run    показать, что будет сделано, ничего не копировать
#   CLAUDE_SKILLS_DIR=/путь sh install.sh   поставить в другую папку
set -eu

FORCE=0; DRY=0
for a in "$@"; do
  case "$a" in
    --force) FORCE=1 ;;
    --dry-run) DRY=1 ;;
    -h|--help) sed -n '2,9p' "$0"; exit 0 ;;
    *) echo "Неизвестный флаг: $a" >&2; exit 2 ;;
  esac
done

HERE=$(cd "$(dirname "$0")" && pwd)
DEST="${CLAUDE_SKILLS_DIR:-$HOME/.claude/skills}"
TS=$(date +%Y%m%d-%H%M%S)
FAIL=0

[ -d "$HERE/skills" ] || { echo "Не найдена папка skills рядом со скриптом." >&2; exit 1; }
echo "Папка скилов: $DEST"
[ "$DRY" = 1 ] || mkdir -p "$DEST"

for src in "$HERE"/skills/*/; do
  name=$(basename "$src")
  target="$DEST/$name"
  if [ ! -f "$src/SKILL.md" ]; then echo "  ! $name: нет SKILL.md в пакете"; FAIL=1; continue; fi
  if [ -e "$target" ]; then
    if [ "$FORCE" = 0 ]; then echo "  = $name уже стоит, пропускаю (добавьте --force, чтобы заменить)"; continue; fi
    BAK="$(dirname "$DEST")/skills-backup-$TS"
    echo "  ~ $name: старая копия уходит в $BAK/$name"
    [ "$DRY" = 1 ] || { mkdir -p "$BAK"; mv "$target" "$BAK/$name"; }
  fi
  echo "  + $name"
  [ "$DRY" = 1 ] || cp -R "$src" "$target"
done

[ "$DRY" = 1 ] && { echo "Пробный запуск, файлы не менялись."; exit 0; }

echo "Проверка:"
for src in "$HERE"/skills/*/; do
  name=$(basename "$src"); f="$DEST/$name/SKILL.md"
  if [ -f "$f" ] && [ "$(head -n 1 "$f")" = "---" ] && grep -q "^name: $name\$" "$f"; then
    echo "  ok $name"
  else
    echo "  ОШИБКА $name: SKILL.md отсутствует или заголовок не совпадает с именем папки"; FAIL=1
  fi
done

if command -v python3 >/dev/null 2>&1 && [ -f "$DEST/higgsfield/scripts/seedance_lint.py" ]; then
  if python3 "$DEST/higgsfield/scripts/seedance_lint.py" --help >/dev/null 2>&1; then
    echo "  ok линтер промптов запускается"
  else
    echo "  ! линтер не запустился: нужен Python 3.9 или новее"
  fi
else
  echo "  - Python 3 не найден: скрипты проверки промптов не заработают (сами скилы работают без него)"
fi

echo
if command -v higgsfield >/dev/null 2>&1; then
  echo "CLI higgsfield найден: $(command -v higgsfield)"
  echo "Если ещё не входили:  higgsfield auth login"
else
  echo "CLI higgsfield не найден. Он нужен для запуска генерации (скилы без него только пишут промпты)."
  echo "Установка:  brew install higgsfield-ai/tap/higgsfield"
  echo "Вход:       higgsfield auth login"
fi
echo "Официальные скилы платформы (по желанию):  npx skills add higgsfield-ai/skills"
echo "Скилы автора ролика уже в пакете: /higgsfield-prompt-engine, /higgsfield-acting-skill, /higgsfield-anamorphic-skill, /higgsfield-fight-scene."
echo
[ "$FAIL" = 0 ] && echo "Готово. Перезапустите Claude Code и вызовите /higgsfield-film-workflow." || { echo "Установка завершена с ошибками."; exit 1; }
