---
name: higgsfield-acting-skill
description: Tigran's method for writing ACTING TASK blocks in AI video prompts (Seedance / Higgsfield) and for directing character performance in any scene work. Use WHENEVER a prompt or scene needs character acting direction — dialogue delivery, emotional beats, "make the eyes alive," listening behavior, reaction shots — or when the user says a character reads dead, glassy, flat, or over-acted. These definitions are bespoke (Tigran's directing school); do NOT substitute textbook craft definitions. Companion to higgsfield-prompt-engine (structure level); this skill is the performance level.
---

# higgsfield-acting-skill

Method for building acting direction that makes AI-generated actors read ALIVE — because the mind behind the face is given real work, not choreography.

**These definitions are Tigran's and are authoritative. Apply exactly as written. Never replace them with textbook Stanislavski summaries.**

---

## Core principle

An acting task is when the character is **INVESTED in his/her tactic of reaching the goal.**

- It is NOT a description of external behavior ("eyes flick," "brows lift," "he looks sad") — that is playing the result, and it produces dead faces.
- It is NOT necessarily physical action. The tactic can live entirely **in the eyes**: a different look when someone humiliates vs. begs; a person arguing from conviction constantly checks BOTH eyes of the partner, hunting for a sparkle of trust, registering whether the partner is interested or drifting — and adjusts to what he finds.
- The eye movement IS the doing. Aliveness = the mind visibly working on the task, moment to moment.
- Never fix dead eyes with lighting tricks (catchlights etc.). Fix them by giving the eyes a task.

## The ladder (work strictly in this order)

### 0. Read the WHOLE scene dialogue first
Never build a task from one line. The task lives across the entire exchange — where it holds, where it breaks. Check every line of every character before directing any of them.

### 1. Goal of the SCENE — one shared direction
The scene has ONE goal: a single direction ALL characters play toward, usually unspoken — a mutual silent agreement about how this time will be lived.
Example (mother packs son's suitcase, army in an hour): the goal of the scene is **make it painless — hide the feeling, don't leave each other with pain or sorrow, never lose the positiveness.** It belongs to both at once.
The scene goal is NOT the film's dramaturgic function (the reveal, the theme). Characters never know or play the film's purposes — those are accomplished THROUGH them, as a byproduct.

### 1a. The ENDING names the event
Always look at how the scene ENDS before naming its event. The last line/beat is the key you read the whole scene backward through. Watch for the double-meaning last line — spoken about one thing, meant about another ("Poor bastard. Just can't forgive himself" — said looking at the patient, meant about himself).

### 1b. ALL in one event
The event must contain EVERY character in the scene — including silent or unconscious ones — as participants or mirrors of the same process. If a character stands outside the named event, the event is named wrong.
Approved example — ONEIRIC Scene 11: event = **"The search for self-forgiveness"** — an initiation into living with the unforgivable. Two compromised men over a third who is literally wired into his own unforgivable day. Alfred can't forgive himself in the dream; the medic can't forgive himself at the bedside (his care for the patient is his penance — he came to earn forgiveness); the doctor stopped trying long ago (his "carelessness" is post-hope scar tissue — he watches the young medic, curious whether THIS one finds the way out of the betrayed conscience he never found). Three mirrors of one sentence; the medic's last line names all three men at once without knowing it. The surface — "routine rounds" — is only the terrain the event moves through, not the event.

### 1c. The PHYSICAL ACTION is the channel
The surface activity of the scene (the "terrain" — e.g., routine rounds; packing a suitcase) stays as the PHYSICAL ACTION, and each character pursues the event THROUGH it — each via his own distinct, visible physical behavior. The invisible task must have a physical channel the camera can read.
Approved example — Scene 11, event "the search for self-forgiveness," physical action "routine rounds":
- **Alfie** — through REMEMBERING: wired into reliving the day (REM under closed lids, the tear).
- **Doctor** — through OBLIGATED ACTIONS DONE RIGHT: writing correct metrics, on time, precisely, maybe double-checking an entry — visually clear that he keeps himself a doctor through flawless procedure; doing everything correctly is what remains of his doctorhood.
- **Medic** — through CARING: patient-care gestures beyond the checklist (checking the man, not the chart).
Rule: give every character in the scene his own physical channel for the same event — different behaviors, one event, one terrain.

### 2. Each character's MOTIVE — different fuel, same direction
Every character pushes along the same scene direction, but each **for his own reason**. The son keeps it painless *for mom*; the mother *out of superstition* (no tears before a journey — bad omen). Same vector, different fuel — the fuel is what makes each performance distinct while the scene reads unified.
Motives can be alternative hypotheses; the director picks. (Lab medic keeping it routine: because he fears looking green in front of the senior — OR because routine professionalism is his way of not betraying his Hippocratic oath, of keeping his humanity inside a place that already compromised him. Same direction; completely different color; choose.)
Given circumstances constrain motives: a man who took the job at an experimental convict lab is ALREADY compromised — he cannot play a moral innocent.

### 3. Each character's GOAL — the personal fight
Born from the motive: what this person is fighting for himself inside the scene. Ordinary, personal, playable. Never the same words as the scene goal, never the theme.

### 4. OBSTACLE — what presses against the direction
The thing threatening to break the scene's line (the real feeling pressing to surface; the case too horrifying to stay routine). One crack and the shared goal collapses. This pressure is what the audience actually feels — precisely because nobody plays it; everyone plays keeping it out.

### 5. TACTIC — the acting task proper
The invested, moment-to-moment pursuit, written as what the character is DOING to the partner — with the eye-work named as purposeful action:
- checking both of the partner's eyes for a sparkle of trust
- registering after each point: did it land? interested or about to smirk?
- stealing looks and snapping back before being caught
- measuring the partner, memorizing him, comparing what I feel with what he shows
Beats are keyed to the actual dialogue words. Where the script demands it, mark the point where a character's fuel runs out and the line breaks (the medic's "...Poor bastard," under his breath — the break IS the delivery of the scene).

## Writing the ACTING TASK block in a prompt

Format inside a Seedance/Higgsfield prompt:

```
ACTING TASK — [NAME] (he is fully invested in his tactic; the work happens in his eyes):
SCENE DIRECTION (shared, unspoken): [one line]
MOTIVE (his fuel): [why HE pushes that direction]
GOAL: [his personal fight]
OBSTACLE: [what presses against the line, what one crack costs]
TACTIC: [what he does to the partner, with the eye-work as action]
Moment to moment:
— "[dialogue words]" — [verb at the partner + what the eyes check]
— "[dialogue words]" — [verb + eye-work]
— [where the line breaks, if it breaks]
(Safety: gaze always engaged in the task — never a frozen, glassy, unfocused stare; natural blink cadence, actors blink now and then to moisturize their eyes.)
```

Rules:
- Verbs directed at the partner; no adjectives of emotion as instruction ("sadly," "nervously").
- No facial choreography ("brows lift," "mouth trembles") — externals only as the safety line above.
- Nobody plays the emotion; everyone plays the direction. The audience receives the feeling through the pressure.
- One safety line against the frozen stare is allowed and recommended (AI-model necessity).
- Every character in frame gets living eyes this way — including silent listeners: a listener's task is also real (e.g., "decide if he's serious," "wait for the punchline," "protect the mood").

## Contrast pairing (build duos on mirrored +/−)

A two-character scene is richer when the pair is built on CONTRAST — each character carries a plus and a minus, mirrored against the other, with one axis being the essential one the audience reads.

Approved example — the lab pair:
- **DOCTOR — Corporate Loyal (+) / CARELESS (−):** genuinely loyal — but to the corporation and the money, not to patients. His plus (loyalty, diligence, professionalism) serves the wrong master. On the essential axis — care for the patient — he is MINUS.
- **MEDIC — Compromised (−) / CARING (+):** compromised by the corporation and the money (he took the job, he knows what this place is) — but caring toward the patient. His minus is real; his plus survives inside it. On the essential axis he is PLUS.

Rules:
- Each character gets one + and one −, inverted relative to the partner.
- Name the ESSENTIAL AXIS of the scene (here: care for the patient) — that opposition is what the audience actually reads; the other traits are the color.
- Both still push the same scene direction (e.g., "keep it routine work") — the contrast lives UNDER the shared direction and leaks out through the tactics and the eyes: the careless one's routine is real; the caring one's routine is armor, and it cracks.
- Motives derive from the +/− build AND from the event: the Medic cares for the patient as his penance — his path to self-forgiveness; the Doctor's flat answers are not dismissal but the quiet experiment — feeding the test and observing whether the young one survives conscience.
- The seeming trait is often scar tissue over its opposite: "careless" = hope lost, not care absent. Direct the history, not the surface.

## Worked example (approved)

Mother/son suitcase scene:
- Scene direction: part without pain, stay positive.
- Her motive: superstition (tears before a journey are a bad omen). His motive: for mom.
- Her goal: send him off strong, don't make him carry her fear. His: leave her calm, show he's ready.
- Obstacle: the real feeling, pressing every second; one wet look and the scene's line collapses.
- Tactic: she packs "ordinarily," eyes stealing to him, measuring, memorizing, snapping back to the socks the moment he looks up; he eats "casually," watching her hands, not her face — because her face is where the danger is.
- The audience cries precisely because nobody on screen does.

## Common failures to catch

- Task built from one line instead of the whole dialogue → re-read the scene first.
- The film's reveal/theme assigned to a character as his task → characters never play the film's purposes.
- Scene goal confused with character goal → scene goal is the shared direction; character goals are personal and differ.
- Motive ignores given circumstances (playing innocence while already complicit) → re-derive motive.
- Prescribed eye/face choreography instead of eye-work as purposeful action → rewrite as verbs at the partner.
- Emotion adjectives as direction → replace with the task that produces the emotion.
