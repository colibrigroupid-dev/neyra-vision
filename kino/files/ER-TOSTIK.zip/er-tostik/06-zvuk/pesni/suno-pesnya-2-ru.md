# Песня 2 · «Сомнение» · русская версия (поющаяся, не подстрочник) · 12.10.2026

**Style** (тот же, язык заменён):
```
Emotional animated film ballad, solo youthful teen vocal: a boy about 15 years old, light vulnerable young voice, slightly breathy, not mature adult timbre, Russian language vocals, intimate piano intro, slowly building strings and soft percussion, melancholic but kid-safe, vulnerable, cinematic swell in the last chorus, dombra texture under the bridge, 72 bpm, minor key turning hopeful at the very end
```

**Lyrics**
```
[Teen vocals, age 15]

[Verse 1]
Все верят в меня, а я в себя не верю,
Снаружи улыбка, а внутри тихий страх.
Мне говорят: «Ты сможешь!» – а я не знаю, как.
А если не смогу? Тогда кто я такой?

[Chorus]
Я тону в сомнениях, я гасну, гасну,
Как тень в тёмной ночи, я исчезаю напрасно.
Кем я могу быть, если не верю в себя?
Ищу ответ – и не нахожу пока.

[Verse 2]
Взрослые смотрят: «Будь батыром, будь сильным»,
А я такой маленький, мой страх больше меня.
А если упаду, если всем станет стыдно –
Не лучше ли просто исчезнуть, растаяв, как дым?

[Chorus]
Я тону в сомнениях, я гасну, гасну,
Как тень в тёмной ночи, я исчезаю напрасно.
Кем я могу быть, если не верю в себя?
Ищу ответ – и не нахожу пока.

[Bridge]
Но... издалека слышу голос, совсем тихий:
«Ты не один».
Кто сказал? Не знаю...
Но сердце впервые спокойно.

[Outro]
Может... может, я не гасну.
Может, я просто ещё не зажёгся.
```
