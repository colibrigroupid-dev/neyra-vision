---
name: montazh
description: Автоматический монтаж видео через ffmpeg — субтитры из речи, склейка кусков, кадрирование под вертикаль, наложение логотипа, извлечение кадров, сжатие. Используй, когда нужно смонтировать ролик, добавить субтитры, склеить заставку с основным видео, сделать вертикаль из горизонтали, наложить лого.
---

# Автомонтаж через ffmpeg

Пути ниже — относительно папки проекта `PROEKTY/<proekt>/`: исходники автора в `materialy/`, результаты в `05-montazh/`, звук в `06-zvuk/`. Имена файлов — латиницей.

Всё, что не умеет генеративная модель: склейка, титры, кадрирование, наложение графики. Делается локально, бесплатно и без потери качества.

## Проверь, что ffmpeg есть

```bash
which ffmpeg ffprobe || ls bin/ffmpeg bin/ffprobe
```

Если нет — ставится без Homebrew, за пару минут:

```bash
uv venv .venv --python 3.11
uv pip install --python .venv/bin/python static-ffmpeg
.venv/bin/static_ffmpeg -version
mkdir -p bin
ln -sf "$(.venv/bin/python -c 'import static_ffmpeg.run as r; print(r.get_or_fetch_platform_executables_else_raise()[0])')" bin/ffmpeg
ln -sf "$(.venv/bin/python -c 'import static_ffmpeg.run as r; print(r.get_or_fetch_platform_executables_else_raise()[1])')" bin/ffprobe
```

Нужна сборка с `libass` и `freetype` — иначе субтитры не выжгутся. Проверить: `bin/ffmpeg -version | grep -o libass`

## Первым делом — узнай, что за файл

Никогда не монтируй вслепую. Разрешение, длительность и кодек определяют всё дальнейшее.

```bash
bin/ffprobe -v error -select_streams v:0 \
  -show_entries stream=width,height,r_frame_rate,codec_name \
  -show_entries format=duration,size \
  -of default=noprint_wrappers=1 materialy/video/rolik.mov
```

## Субтитры из речи

Два шага: расшифровать, потом выжечь.

**Расшифровка.** На Apple Silicon быстрее всего `mlx-whisper`, модель `whisper-large-v3-turbo` понимает русский хорошо:

```bash
uv pip install --python .venv/bin/python mlx-whisper
.venv/bin/python -c "
import mlx_whisper, json
r = mlx_whisper.transcribe('materialy/video/rolik.mov',
    path_or_hf_repo='mlx-community/whisper-large-v3-turbo',
    language='ru', word_timestamps=True)
print(json.dumps(r['segments'], ensure_ascii=False)[:500])
"
```

Дальше сегменты превращаются в `.srt`: номер, тайминг `00:00:01,200 --> 00:00:03,450`, текст, пустая строка.

**Всегда показывай расшифровку автору перед выжиганием.** Whisper ошибается на именах, терминах и названиях — исправить в тексте дёшево, перевыжигать долго.

**Выжигание.** Стиль задаётся через `force_style`:

```bash
bin/ffmpeg -i input.mp4 -vf "subtitles=subs.srt:force_style=\
'FontName=Arial Black,FontSize=16,PrimaryColour=&H00FFFFFF,\
OutlineColour=&H00000000,Outline=2,Shadow=0,Alignment=2,MarginV=60'" \
  -c:a copy 05-montazh/s-subtitrami.mp4
```

Цвета в формате `&HAABBGGRR` — задом наперёд относительно привычного HEX. Белый `&H00FFFFFF`, чёрный `&H00000000`, золотой `&H0000D7FF`.

`Alignment=2` — снизу по центру, `MarginV` — отступ от края в пикселях. Для вертикальных роликов поднимай субтитры выше (`MarginV=250`), чтобы интерфейс соцсети их не перекрыл.

## Горизонталь в вертикаль

Два подхода, выбор зависит от того, что в кадре.

**Обрезать по центру** — когда герой в середине и края не важны:

```bash
bin/ffmpeg -i input.mp4 -vf "crop=ih*9/16:ih,scale=1080:1920" \
  -c:a copy 05-montazh/vertikal.mp4
```

Теряются края кадра. Если герой смещён, сдвинь область: `crop=ih*9/16:ih:x=300:0`.

**Вписать целиком с фоном** — когда терять края нельзя:

```bash
bin/ffmpeg -i input.mp4 -filter_complex \
"[0:v]scale=1080:-2[fg];\
 [0:v]scale=1080:1920:force_original_aspect_ratio=increase,\
 crop=1080:1920,gblur=sigma=40[bg];\
 [bg][fg]overlay=(W-w)/2:(H-h)/2" \
  -c:a copy 05-montazh/vertikal-s-fonom.mp4
```

Здесь фоном становится размытая копия самого видео — выглядит цельно и не требует подбирать цвет.

## Склейка кусков

Обязательное условие: одинаковые разрешение, частота кадров и параметры звука. Иначе получится рассинхрон или обрыв.

Сначала привести всё к общему виду:

```bash
for f in заставка.mp4 основа.mp4 финал.mp4; do
  bin/ffmpeg -i "$f" -vf "scale=1080:1920:force_original_aspect_ratio=decrease,\
pad=1080:1920:(ow-iw)/2:(oh-ih)/2,fps=30" \
    -c:v libx264 -preset medium -crf 18 \
    -c:a aac -ar 48000 -ac 2 "norm_$f"
done
```

Потом склеить:

```bash
printf "file 'norm_заставка.mp4'\nfile 'norm_основа.mp4'\nfile 'norm_финал.mp4'\n" > list.txt
bin/ffmpeg -f concat -safe 0 -i list.txt -c copy 05-montazh/gotovo.mp4
```

С плавным переходом между кусками вместо резкой склейки:

```bash
bin/ffmpeg -i a.mp4 -i b.mp4 -filter_complex \
"[0:v][1:v]xfade=transition=fade:duration=0.5:offset=4.5[v];\
 [0:a][1:a]acrossfade=d=0.5[a]" -map "[v]" -map "[a]" 05-montazh/skleyka.mp4
```

`offset` — момент начала перехода, обычно длительность первого куска минус длительность перехода.

## Логотип поверх видео

**Настоящий логотип из файла, а не сгенерированный моделью.** Генеративные модели искажают текст и мелкие детали — фирменный знак выйдет похожим, но кривым.

```bash
bin/ffmpeg -i video.mp4 -i materialy/logo.png -filter_complex \
"[1:v]scale=200:-1[lg];[0:v][lg]overlay=W-w-40:40" \
  -c:a copy 05-montazh/s-logo.mp4
```

Позиция: `W-w-40:40` — правый верх, `40:H-h-40` — левый низ, `(W-w)/2:(H-h)/2` — центр.

Появление только в конце, с проявлением:

```bash
bin/ffmpeg -i video.mp4 -i logo.png -filter_complex \
"[1:v]scale=300:-1,format=rgba,\
 fade=in:st=0:d=0.5:alpha=1[lg];\
 [0:v][lg]overlay=(W-w)/2:(H-h)/2:enable='gte(t,20)'" \
  -c:a copy 05-montazh/final.mp4
```

`enable='gte(t,20)'` — показывать начиная с двадцатой секунды.

## Полезная мелочь

**Кадр из видео** — пригодится как референс для генерации:
```bash
bin/ffmpeg -i video.mp4 -ss 00:00:03 -frames:v 1 05-montazh/kadr.png
```

**Последний кадр** — чтобы продлить ролик генерацией:
```bash
bin/ffmpeg -sseof -0.1 -i video.mp4 -frames:v 1 -q:v 1 05-montazh/posledniy.png
```

**Отрезать кусок** без перекодирования:
```bash
bin/ffmpeg -ss 00:00:05 -to 00:00:15 -i video.mp4 -c copy 05-montazh/kusok.mp4
```

**Вытащить звук** для расшифровки:
```bash
bin/ffmpeg -i video.mp4 -vn -acodec pcm_s16le -ar 16000 -ac 1 06-zvuk/audio.wav
```

**Сжать под соцсети** без заметной потери:
```bash
bin/ffmpeg -i video.mp4 -c:v libx264 -crf 23 -preset slow \
  -c:a aac -b:a 128k 05-montazh/szhato.mp4
```

## Правила, которые берегут материал

**Исходник не трогай.** Всё пишется в `05-montazh/`, оригинал остаётся в `materialy/`.

**`-c copy` там, где можно.** Копирование потока вместо перекодирования не теряет качество и работает мгновенно. Годится для обрезки и склейки одинаковых файлов.

**`-crf` вместо битрейта.** 18 — визуально без потерь, 23 — хорошее качество при разумном весе, 28 — заметно хуже.

**Проверяй результат** через `ffprobe` после сборки: сошлись ли длительность, разрешение и наличие звука с ожиданием.

**Длинные команды объясняй.** Автор должна понимать, что делает каждая строка, а не запускать вслепую.
