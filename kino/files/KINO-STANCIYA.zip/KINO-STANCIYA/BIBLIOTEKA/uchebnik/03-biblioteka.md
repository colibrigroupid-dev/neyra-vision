# 03. Библиотека сценариев: источники, индекс, загрузчик

Сверка: 2026-10-12. Ссылки проверены запросами curl и WebFetch, а не по памяти. Где ссылки не работают или не проверены, сказано прямо. Тексты: IMSDb — фанатские транскрипции; часть PDF на ScriptSlug — неофициальные копии; часть FYC-PDF — студийные копии для наград. Всё для личного изучения, не для публикации и перепродажи.

## 0. Итоги проверки

- Позиций в индексе фильмов и сериалов: 176. С рабочей ссылкой на текст: 133. Без проверенной ссылки: 43 (раздел 3).
- IMSDb: страница открывается у 138, но реальный текст есть только у 76. У 62 страниц — заглушка без текста (7–8 КБ, «Writers» пустой). В индекс позиция засчитана, только если есть текст на IMSDb или рабочий PDF на ScriptSlug.
- ScriptSlug: страница открывается у 130 из 176. PDF по ссылке отдаёт настоящий файл (сигнатура %PDF) у 128. Текстовый слой проверен только у скачанных файлов.
- Всего проверочных запросов: около 700 (страницы, PDF, повторная сверка IMSDb и сценаристов).
- Скачано: 55 сценариев на английском (`BIBLIOTEKA/scenarii/en/`) и 5 русских (`BIBLIOTEKA/scenarii/ru/`). Файлы, объём и проблемы — в разделе 6.
- Оскаровские списки 2000–2026 сверены с Википедией (раздел 4). IMDb Top 250 в этом прогоне не сверялся.

## 1. Карта источников сценариев

| Источник | Что там | Легальность и статус | Формат | Как искать | Проверено |
|---|---|---|---|---|---|
| IMSDb (imsdb.com) | Большая база фильмов и ТВ-транскриптов. Часть страниц — заглушки без текста (сейчас у 62 из 138 проверенных) | Серая зона: фанатские транскрипции, часть — неофициальные копии. Только для личного изучения | HTML, текст в `<pre>` | /scripts/Название.html; артикль в конце: `Godfather,-The.html`; список /all-scripts.html | Да: 138 страниц отвечают 200; реальный текст у 76 |
| ScriptSlug (scriptslug.com) | Каталог фильмов с PDF; на страницах — сценаристы и описание | Серая зона: PDF часто неофициальные копии, происхождение не везде указано | PDF с assets.scriptslug.com | /script/название-год | Да: 130 из 176 страниц 200, PDF отдают %PDF |
| SimplyScripts (simplyscripts.com) | По странице: около 1 376 movie scripts и 64 TV; часть — PDF | Серая зона, права не указаны | HTML и PDF | /movie-scripts, поиск по сайту | Частично: раздел открывается, отдельные PDF не проверял |
| The Daily Script (thedailyscript.com) | Сотни сценариев, в т.ч. The Prestige, Panic Room, Deliverance (по странице SimplyScripts и поиску) | Серая зона, права не указаны | PDF, часть HTML | Поиск по сайту | Частично: сайт отвечает 200, конкретные ссылки не проверял |
| The Script Lab (thescriptlab.com) | По заявлению сайта — 1600+ сценариев фильмов и ТВ; скачивание бесплатное; по одному источнику нужен аккаунт | По заявлению сайта публикуются только сценарии, выложенные правообладателями | PDF | Script Library, поиск | Нет: сайт не отвечал из среды; данные из поиска |
| Scripts on Screen (scriptsonscreen.com) | Библиотека сценариев (по описанию в задаче) | Не проверено | — | — | Нет: сайт не отвечал из среды |
| BBC Writersroom, Script Library (bbc.co.uk/writersroom/scripts) | Радио- и ТВ-сценарии BBC, в т.ч. Doctor Who сезона 12 (все 10 серий в PDF) | Легально: бесплатно от BBC (подтверждено поиском, не страницей) | PDF | bbc.co.uk/writersroom/scripts | Частично: curl отдаёт 200; WebFetch из среды не открыл |
| John August, Library (johnaugust.com/library) | Авторские сценарии: Go, Big Fish, Charlie and the Chocolate Factory, Frankenweenie, The Nines, D.C. (пилот), Fried Worms; плюс Station Eleven и Chernobyl с разрешения шоураннеров | Легально: авторские материалы. На сайте — «только для обучения», не продавать, не копировать | PDF | /library | Да: WebFetch, ссылки взяты со страницы |
| Go Into The Story (gointothestory.blcklst.com) | Блог Black List: статьи, интервью, новости продаж спек-сценариев | Легально, но сценарии не выкладывает | — | — | Да: WebFetch, сценариев нет |
| Writers Guild Foundation (wgfoundation.org) | Shavelson-Webb Library: каталог и читальный зал; онлайн-текстов по сайту не видно | Очный доступ; онлайн не подтверждено | — | librarycatalog.wgfoundation.org, запись на визит | Да: страницы 200, онлайн-текстов не найдено |
| Academy, Margaret Herrick Library | Фонд сценариев и книг, очный доступ в Лос-Анджелесе | Легально; онлайн-доступ ограничен | — | oscars.org, Margaret Herrick Library | Нет: oscars.org отвечает 403 на запросы из среды |
| A24 (a24films.com) | FYC-PDF по сезонам наград. Отдельного раздела со сценариями не нашёл (/scripts — 404) | Легально (студийные копии для кампании), доступны только в сезон | PDF | Сезонные списки Film Buff Online и Deadline; сборка 2026 года — у сообщества (Reddit), ссылка на общую папку Google Drive | Частично: главная 200, /scripts 404; папку Drive не открывал |
| Focus Features, Searchlight, Neon | Исторически выкладывали FYC-PDF по сезонам (по поиску: Searchlight в сезоне 2025 — A Complete Unknown и др.) | Легально, но временно | PDF | Раздел awards на сайте студии, списки Deadline и Film Buff Online | Частично: searchlightpictures.com/awards/ 200; focusfeatures.com/awards и neonrated.com/awards — 404 |
| Netflix FYC (netflixawards.com) | Страница кампании, сценариев нет | — | — | — | Да: WebFetch, сценариев нет |
| Sony Pictures Classics, FYC | Заявлен раздел screenplays; ссылка на Loveless (Нелюбовь) отдаёт HTML, а не PDF | Ссылка не работает | — | sonyclassics.com/awards-information/ | Да: PDF не получен, в индекс не включён |
| Deadline, Variety, Film Buff Online | Списки и ссылки на FYC-сценарии по годам | Легально (публикации студий) | PDF, ссылки | Поиск «For Your Consideration screenplay» + год | Да: deadline.com 200; списки Film Buff Online найдены поиском |
| Kinodramaturg.ru | Русские и иностранные сценарии с PDF. Часть — публикации продюсеров (Bazelevs, Art Pictures) с указанием источника; часть — переводы сайта | Смешанный: студийные публикации — легально; переводы — права не проверены | PDF | /scenarii/rus_scenarii/, /scenarii/ino_scenarii/ | Да: PDF отдаются как application/pdf; скачано 5 |
| Screenwriter.ru | Конкурс сценариев: логлайны, синопсисы, заявки; библиотекой не является | Легально (сайт конкурса) | — | — | Да: сценарии классики не найдены |
| lib.ru, раздел /CINEMA/ | Раздел про кино, кодировка koi8-r; собственных текстов сценариев не найдено, есть внешние ссылки (в т.ч. «Избранные сценарии ВГИК 2000») | Советская классика — права у наследников. Открытых легальных текстов не подтверждено. Пиратские библиотеки не использовались | — | lib.ru/CINEMA/ | Да: раздел открыт, полных текстов не подтверждено |
| Сайты авторов (beingcharliekaufman.com, sorkin.com) | Сайты Чарли Кауфмана и Аарона Соркина | Права авторов. Тексты сценариев не проверял | — | Главные страницы | Да: 200, содержимое сценариев не проверено |

Советская классика (Тарковский, Шпаликов): легальных открытых PDF не найдено. Подтверждённые варианты: «Collected Screenplays» Тарковского (Faber, на английском); «Избранное» Шпаликова (М.: Искусство, 1979, в библиотеках); «Сценарий фильма «Зеркало»» (бумажное издание). Статья Дединского о мультфильме «Жил-был Козявин» (журнал «Киноархив», 2022, открытый доступ на gitis.net) — научный разбор, полного текста там нет.

## 2. Индекс: фильмы с проверенной ссылкой (133)

«Сценарист(ы)» взяты со страницы источника, сверка по ScriptSlug (там же описание). Для позиций только с IMSDb — по заголовку страницы. «Скачан» — файл лежит в `BIBLIOTEKA/scenarii/en/`.

| № | Фильм (оригинал / русское) | Год | Сценарист(ы) | Жанр | За что изучать | IMSDb | ScriptSlug | Скачан |
|---|---|---|---|---|---|---|---|---|
| 1 | Citizen Kane / Гражданин Кейн | 1941 | Orson Welles and Herman J. Mankiewicz | драма | нелинейность, рассказ через свидетелей | [да](https://imsdb.com/scripts/Citizen-Kane.html) | [да](https://www.scriptslug.com/script/citizen-kane-1941) (PDF) | да |
| 2 | Casablanca / Касабланка | 1942 | Julius J. Epstein, Philip G. Epstein, and Howard Koch | драма | структура на одной локации, подтекст в диалоге | — | [да](https://www.scriptslug.com/script/casablanca-1942) (PDF) | да |
| 3 | Rear Window / Окно во двор | 1954 | Cornell Woolrich and John Michael Hayes | триллер | ограниченная локация, экспозиция через наблюдение | [да](https://imsdb.com/scripts/Rear-Window.html) | [да](https://www.scriptslug.com/script/rear-window-1954) (PDF) | — |
| 4 | 12 Angry Men / 12 разгневанных мужчин | 1957 | Reginald Rose | драма | диалог в одной комнате | — | [да](https://www.scriptslug.com/script/12-angry-men-1957) (PDF) | да |
| 5 | Vertigo / Головокружение | 1958 | Alec Coppel and Samuel A. Taylor | триллер | двойники, манипуляция зрителем | — | [да](https://www.scriptslug.com/script/vertigo-1958) (PDF) | да |
| 6 | North by Northwest / К северу через северо-запад | 1959 | Ernest Lehman | триллер | макгаффин, темп погони | — | [да](https://www.scriptslug.com/script/north-by-northwest-1959) (PDF) | — |
| 7 | Psycho / Психо | 1960 | Joseph Stefano and Robert Bloch | триллер | смена протагониста в середине | [да](https://imsdb.com/scripts/Psycho.html) | [да](https://www.scriptslug.com/script/psycho-1960) (PDF) | да |
| 8 | The Apartment / Квартира | 1960 | Billy Wilder and I.A.L. Diamond | комедия/драма | мораль в комедии, тайминг | [да](https://imsdb.com/scripts/Apartment,-The.html) | [да](https://www.scriptslug.com/script/the-apartment-1960) (PDF) | — |
| 9 | 2001: A Space Odyssey / 2001: Космическая одиссея | 1968 | Stanley Kubrick and Arthur C. Clarke | sci-fi | минимум диалогов, структура | [да](https://imsdb.com/scripts/2001-A-Space-Odyssey.html) | [да](https://www.scriptslug.com/script/2001-a-space-odyssey-1968) (PDF) | да |
| 10 | A Clockwork Orange / Заводной апельсин | 1971 | Stanley Kubrick and Anthony Burgess | драма/сатира | рассказ от первого лица | — | [да](https://www.scriptslug.com/script/a-clockwork-orange-1971) (PDF) | — |
| 11 | The Godfather / Крёстный отец | 1972 | Francis Ford Coppola and Mario Puzo | криминал/драма | экспозиция через свадьбу, сцена как характеристика | — | [да](https://www.scriptslug.com/script/the-godfather-1972) (PDF) | да |
| 12 | Chinatown / Китайский квартал | 1974 | Robert Towne | нуар/детектив | тайна, ложный след, третий акт | [да](https://imsdb.com/scripts/Chinatown.html) | [да](https://www.scriptslug.com/script/chinatown-1974) (PDF) | да |
| 13 | Jaws / Челюсти | 1975 | Peter Benchley and Carl Gottlieb | триллер | саспенс через отложенное появление | [да](https://imsdb.com/scripts/Jaws.html) | [да](https://www.scriptslug.com/script/jaws-1975) (PDF) | да |
| 14 | Network / Телесеть | 1976 | Paddy Chayefsky | сатира/драма | монологи, сатира | — | [да](https://www.scriptslug.com/script/network-1976) (PDF) | да |
| 15 | Rocky / Рокки | 1976 | Sylvester Stallone | драма | арка аутсайдера | [да](https://imsdb.com/scripts/Rocky.html) | [да](https://www.scriptslug.com/script/rocky-1976) (PDF) | — |
| 16 | Taxi Driver / Таксист | 1976 | Paul Schrader | драма/триллер | внутренний монолог, арка персонажа | [да](https://imsdb.com/scripts/Taxi-Driver.html) | [да](https://www.scriptslug.com/script/taxi-driver-1976) (PDF) | да |
| 17 | Annie Hall / Энни Холл | 1977 | Woody Allen | комедия | нелинейность, закадровый разговор | [да](https://imsdb.com/scripts/Annie-Hall.html) | [да](https://www.scriptslug.com/script/annie-hall-1977) (PDF) | — |
| 18 | Alien / Чужой | 1979 | Dan O'Bannon and Ronald Shusett | sci-fi/хоррор | саспенс, экономия экспозиции | [да](https://imsdb.com/scripts/Alien.html) | [да](https://www.scriptslug.com/script/alien-1979) (PDF) | да |
| 19 | Apocalypse Now / Апокалипсис сегодня | 1979 | John Milius and Francis Ford Coppola | война/драма | структура путешествия | [да](https://imsdb.com/scripts/Apocalypse-Now.html) | [да](https://www.scriptslug.com/script/apocalypse-now-1979) (PDF) | — |
| 20 | The Shining / Сияние | 1980 | Stanley Kubrick, Diane Johnson, and Stephen King | хоррор | повествование через бытовое | [да](https://imsdb.com/scripts/Shining,-The.html) | [да](https://www.scriptslug.com/script/the-shining-1980) (PDF) | да |
| 21 | Raiders of the Lost Ark / Охотники за утраченным ковчегом | 1981 | Lawrence Kasdan | приключения | приключенческий ритм | — | [да](https://www.scriptslug.com/script/raiders-of-the-lost-ark-1981) (PDF) | — |
| 22 | Blade Runner / Бегущий по лезвию | 1982 | David Peoples and Hampton Fancher | sci-fi | мир, монологи | [да](https://imsdb.com/scripts/Blade-Runner.html) | [да](https://www.scriptslug.com/script/blade-runner-1982) (PDF) | да |
| 23 | E.T. the Extra-Terrestrial / Инопланетянин | 1982 | Melissa Mathison | фантастика | детская точка зрения | [да](https://imsdb.com/scripts/E.T..html) | [да](https://www.scriptslug.com/script/et-the-extra-terrestrial-1982) (PDF) | — |
| 24 | Amadeus / Амадей | 1984 | Peter Shaffer | драма | рассказчик-антагонист | [да](https://imsdb.com/scripts/Amadeus.html) | [да](https://www.scriptslug.com/script/amadeus-1984) (PDF) | — |
| 25 | The Terminator / Терминатор | 1984 | James Cameron | sci-fi/боевик | экономия экспозиции | — | [да](https://www.scriptslug.com/script/the-terminator-1984) (PDF) | — |
| 26 | Back to the Future / Назад в будущее | 1985 | Bob Gale and Robert Zemeckis | фантастика/комедия | сетапы и пэйоффы | — | [да](https://www.scriptslug.com/script/back-to-the-future-1985) (PDF) | — |
| 27 | Full Metal Jacket / Цельнометаллическая оболочка | 1987 | Stanley Kubrick, Michael Herr, and Gustav Hasford | война | разрыв структуры на два акта | — | [да](https://www.scriptslug.com/script/full-metal-jacket-1987) (PDF) | — |
| 28 | Die Hard / Крепкий орешек | 1988 | Steven E. de Souza | боевик | рамка одной ночи | [да](https://imsdb.com/scripts/Die-Hard.html) | [да](https://www.scriptslug.com/script/die-hard-1988) (PDF) | — |
| 29 | Dead Poets Society / Клуб мёртвых поэтов | 1989 | Tom Schulman | драма | арка учителя | [да](https://imsdb.com/scripts/Dead-Poets-Society.html) | [да](https://www.scriptslug.com/script/dead-poets-society-1989) (PDF) | — |
| 30 | When Harry Met Sally... / Когда Гарри встретил Салли | 1989 | Nora Ephron | комедия | диалог | — | [да](https://www.scriptslug.com/script/when-harry-met-sally-1989) (PDF) | — |
| 31 | Goodfellas / Славные парни | 1990 | Nicholas Pileggi and Martin Scorsese | криминал | голос за кадром, темп | — | [да](https://www.scriptslug.com/script/goodfellas-1990) (PDF) | — |
| 32 | The Silence of the Lambs / Молчание ягнят | 1991 | Ted Tally | триллер | диалоги-допросы | — | [да](https://www.scriptslug.com/script/the-silence-of-the-lambs-1991) (PDF) | да |
| 33 | Thelma & Louise / Тельма и Луиза | 1991 | Callie Khouri | драма | дорожный сюжет | — | [да](https://www.scriptslug.com/script/thelma-and-louise-1991) (PDF) | — |
| 34 | Reservoir Dogs / Бешеные псы | 1992 | Quentin Tarantino | криминал | одна локация, флешбэки | [да](https://imsdb.com/scripts/Reservoir-Dogs.html) | [да](https://www.scriptslug.com/script/reservoir-dogs-1992) (PDF) | — |
| 35 | Groundhog Day / День сурка | 1993 | Danny Rubin | комедия | петля времени | [да](https://imsdb.com/scripts/Groundhog-Day.html) | [да](https://www.scriptslug.com/script/groundhog-day-1993) (PDF) | — |
| 36 | Schindler's List / Список Шиндлера | 1993 | Steven Zaillian | драма | документальная точность | — | [да](https://www.scriptslug.com/script/schindlers-list-1993) (PDF) | — |
| 37 | Forrest Gump / Форрест Гамп | 1994 | Eric Roth and Winston Groom | драма | сюжет через историю героя | [да](https://imsdb.com/scripts/Forrest-Gump.html) | [да](https://www.scriptslug.com/script/forrest-gump-1994) (PDF) | да |
| 38 | Pulp Fiction / Криминальное чтиво | 1994 | Quentin Tarantino and Roger Avary | криминал | нелинейность, диалог | [да](https://imsdb.com/scripts/Pulp-Fiction.html) | [да](https://www.scriptslug.com/script/pulp-fiction-1994) (PDF) | да |
| 39 | The Shawshank Redemption / Побег из Шоушенка | 1994 | Frank Darabont | драма | рассказчик, структура времени | [да](https://imsdb.com/scripts/Shawshank-Redemption,-The.html) | [да](https://www.scriptslug.com/script/the-shawshank-redemption-1994) (PDF) | да |
| 40 | Heat / Схватка | 1995 | Michael Mann | криминал | две линии | [да](https://imsdb.com/scripts/Heat.html) | [да](https://www.scriptslug.com/script/heat-1995) (PDF) | — |
| 41 | Se7en / Семь | 1995 | Andrew Kevin Walker | триллер | структура расследования | [да](https://imsdb.com/scripts/Se7en.html) | [да](https://www.scriptslug.com/script/se7en-1995) (PDF) | да |
| 42 | Toy Story / История игрушек | 1995 | Alec Sokolow, Andrew Stanton, Joel Cohen, and Joss Whedon | анимация | структура группы героев | [да](https://imsdb.com/scripts/Toy-Story.html) | [да](https://www.scriptslug.com/script/toy-story-1995) (PDF) | да |
| 43 | Fargo / Фарго | 1996 | Joel Coen and Ethan Coen | криминал | диалект, юмор | [да](https://imsdb.com/scripts/Fargo.html) | [да](https://www.scriptslug.com/script/fargo-1996) (PDF) | да |
| 44 | Good Will Hunting / Умница Уилл Хантинг | 1997 | Matt Damon and Ben Affleck | драма | арка учитель-ученик | [да](https://imsdb.com/scripts/Good-Will-Hunting.html) | [да](https://www.scriptslug.com/script/good-will-hunting-1997) (PDF) | да |
| 45 | Titanic / Титаник | 1997 | James Cameron | драма | рамочная структура | [да](https://imsdb.com/scripts/Titanic.html) | [да](https://www.scriptslug.com/script/titanic-1997) (PDF) | — |
| 46 | The Big Lebowski / Большой Лебовски | 1998 | Ethan Coen and Joel Coen | комедия | рассказ от третьего лица | [да](https://imsdb.com/scripts/Big-Lebowski,-The.html) | [да](https://www.scriptslug.com/script/the-big-lebowski-1998) (PDF) | — |
| 47 | American Beauty / Красота по-американски | 1999 | Alan Ball | драма | закадровый голос мёртвого | [да](https://imsdb.com/scripts/American-Beauty.html) | [да](https://www.scriptslug.com/script/american-beauty-1999) (PDF) | — |
| 48 | Being John Malkovich / Быть Джоном Малковичем | 1999 | Charlie Kaufman | комедия | абсурд, структура | [да](https://imsdb.com/scripts/Being-John-Malkovich.html) | [да](https://www.scriptslug.com/script/being-john-malkovich-1999) (PDF) | — |
| 49 | Fight Club / Бойцовский клуб | 1999 | Jim Uhls and Chuck Palahniuk | драма/триллер | ненадёжный рассказчик | [да](https://imsdb.com/scripts/Fight-Club.html) | [да](https://www.scriptslug.com/script/fight-club-1999) (PDF) | да |
| 50 | The Matrix / Матрица | 1999 | Lilly Wachowski and Lana Wachowski | sci-fi | экспозиция через действие | [да](https://imsdb.com/scripts/Matrix,-The.html) | [да](https://www.scriptslug.com/script/the-matrix-1999) (PDF) | да |
| 51 | The Sixth Sense / Шестое чувство | 1999 | M. Night Shyamalan | триллер | твист | [да](https://imsdb.com/scripts/Sixth-Sense,-The.html) | [да](https://www.scriptslug.com/script/the-sixth-sense-1999) (PDF) | — |
| 52 | Gladiator / Гладиатор | 2000 | David Franzoni, John Logan, and William Nicholson | боевик/драма | структура мести | [да](https://imsdb.com/scripts/Gladiator.html) | [да](https://www.scriptslug.com/script/gladiator-2000) (PDF) | — |
| 53 | Memento / Помни | 2000 | Christopher Nolan and Jonathan Nolan | триллер | обратная хронология | [да](https://imsdb.com/scripts/Memento.html) | [да](https://www.scriptslug.com/script/memento-2000) (PDF) | да |
| 54 | Adaptation. / Адаптация | 2002 | Charlie Kaufman and Susan Orlean | комедия | сценарист в сюжете | — | [да](https://www.scriptslug.com/script/adaptation-2002) (PDF) | да |
| 55 | Minority Report / Особое мнение | 2002 | Scott Frank, Jon Cohen, and Philip K. Dick | sci-fi | структура | [да](https://imsdb.com/scripts/Minority-Report.html) | [да](https://www.scriptslug.com/script/minority-report-2002) (PDF) | — |
| 56 | Finding Nemo / В поисках Немо | 2003 | Andrew Stanton, Bob Peterson, and David Reynolds | анимация | путешествие, эмоциональная арка | [да](https://imsdb.com/scripts/Finding-Nemo.html) | [да](https://www.scriptslug.com/script/finding-nemo-2003) (PDF) | — |
| 57 | Lost in Translation / Трудности перевода | 2003 | Sofia Coppola | драма | подтекст | [да](https://imsdb.com/scripts/Lost-in-Translation.html) | [да](https://www.scriptslug.com/script/lost-in-translation-2003) (PDF) | да |
| 58 | Crash / Столкновение | 2004 | Paul Haggis and Bobby Moresco | драма | ансамбль | [да](https://imsdb.com/scripts/Crash.html) | [да](https://www.scriptslug.com/script/crash-2004) (PDF) | — |
| 59 | Eternal Sunshine of the Spotless Mind / Вечное сияние чистого разума | 2004 | Charlie Kaufman | драма/sci-fi | структура памяти | [да](https://imsdb.com/scripts/Eternal-Sunshine-of-the-Spotless-Mind.html) | [да](https://www.scriptslug.com/script/eternal-sunshine-of-the-spotless-mind-2004) (PDF) | да |
| 60 | Million Dollar Baby / Малышка на миллион | 2004 | Paul Haggis | драма | структура | — | [да](https://www.scriptslug.com/script/million-dollar-baby-2004) (PDF) | — |
| 61 | Shaun of the Dead / Зомби по имени Шон | 2004 | Edgar Wright and Simon Pegg | комедия | сетапы | — | [да](https://www.scriptslug.com/script/shaun-of-the-dead-2004) (PDF) | — |
| 62 | Sideways / Сайдвейз | 2004 | — | комедия/драма | дорожный сюжет | [да](https://imsdb.com/scripts/Sideways.html) | — | да |
| 63 | Brokeback Mountain / Горбатая гора | 2005 | Larry McMurtry and Diana Ossana | драма | подтекст | — | [да](https://www.scriptslug.com/script/brokeback-mountain-2005) (PDF) | — |
| 64 | Children of Men / Дети людей | 2006 | Alfonso Cuarón, Timothy J. Sexton, David Arata, Mark Fergus, and Hawk Ostby | sci-fi | длинные сцены | — | [да](https://www.scriptslug.com/script/children-of-men-2006) (PDF) | — |
| 65 | Little Miss Sunshine / Маленькая мисс Счастье | 2006 | Michael Arndt | комедия | ансамбль | — | [да](https://www.scriptslug.com/script/little-miss-sunshine-2006) (PDF) | да |
| 66 | Pan's Labyrinth / Лабиринт Пана | 2006 | Guillermo del Toro | фэнтези | двойной мир | — | [да](https://www.scriptslug.com/script/pans-labyrinth-2006) (PDF) | — |
| 67 | The Departed / Отступники | 2006 | William Monahan | криминал | двойная интрига | [да](https://imsdb.com/scripts/Departed,-The.html) | [да](https://www.scriptslug.com/script/the-departed-2006) (PDF) | — |
| 68 | Hot Fuzz / Холодное оружие | 2007 | Edgar Wright and Simon Pegg | комедия | структура жанра-пародии | — | [да](https://www.scriptslug.com/script/hot-fuzz-2007) (PDF) | — |
| 69 | Juno / Джуно | 2007 | Diablo Cody | комедия | голос персонажа | [да](https://imsdb.com/scripts/Juno.html) | [да](https://www.scriptslug.com/script/juno-2007) (PDF) | да |
| 70 | No Country for Old Men / Старикам тут не место | 2007 | Joel Coen and Ethan Coen | триллер | структура, молчание | [да](https://imsdb.com/scripts/No-Country-for-Old-Men.html) | [да](https://www.scriptslug.com/script/no-country-for-old-men-2007) (PDF) | да |
| 71 | Ratatouille / Рататуй | 2007 | Brad Bird | анимация | зритель-посредник | — | [да](https://www.scriptslug.com/script/ratatouille-2007) (PDF) | да |
| 72 | Frost/Nixon / Фрост против Никсона | 2008 | Peter Morgan | драма | дебаты | — | [да](https://www.scriptslug.com/script/frost-nixon-2008) (PDF) | — |
| 73 | Milk / Милк | 2008 | — | биография | речь | [да](https://imsdb.com/scripts/Milk.html) | — | — |
| 74 | Slumdog Millionaire / Миллионер из трущоб | 2008 | — | драма | рамочная структура | [да](https://imsdb.com/scripts/Slumdog-Millionaire.html) | — | — |
| 75 | The Hurt Locker / В ловушке времени | 2008 | Mark Boal | война | документальный ритм | [да](https://imsdb.com/scripts/Hurt-Locker,-The.html) | [да](https://www.scriptslug.com/script/the-hurt-locker-2008) (PDF) | — |
| 76 | WALL-E / ВАЛЛ-И | 2008 | Andrew Stanton and Jim Reardon | анимация | экспозиция без диалогов | — | [да](https://www.scriptslug.com/script/wall-e-2008) (PDF) | — |
| 77 | Inglourious Basterds / Бесславные ублюдки | 2009 | Quentin Tarantino | военный | главы | [да](https://imsdb.com/scripts/Inglourious-Basterds.html) | [да](https://www.scriptslug.com/script/inglourious-basterds-2009) (PDF) | — |
| 78 | Up / Вверх | 2009 | Bob Peterson and Pete Docter | анимация | немой пролог, монтаж | [да](https://imsdb.com/scripts/Up.html) | [да](https://www.scriptslug.com/script/up-2009) (PDF) | — |
| 79 | Inception / Начало | 2010 | Christopher Nolan | sci-fi/триллер | многоуровневая структура | [да](https://imsdb.com/scripts/Inception.html) | [да](https://www.scriptslug.com/script/inception-2010) (PDF) | — |
| 80 | The King's Speech / Король говорит | 2010 | David Seidler | драма | диалог-терапия | — | [да](https://www.scriptslug.com/script/the-kings-speech-2010) (PDF) | — |
| 81 | The Social Network / Социальная сеть | 2010 | Aaron Sorkin | драма | диалог, нелинейность | [да](https://imsdb.com/scripts/Social-Network,-The.html) | [да](https://www.scriptslug.com/script/the-social-network-2010) (PDF) | да |
| 82 | Drive / Драйв | 2011 | Hossein Amini | криминал | молчаливый герой | [да](https://imsdb.com/scripts/Drive.html) | [да](https://www.scriptslug.com/script/drive-2011) (PDF) | — |
| 83 | Midnight in Paris / Полночь в Париже | 2011 | Woody Allen | комедия | фантастика и ностальгия | [да](https://imsdb.com/scripts/Midnight-in-Paris.html) | [да](https://www.scriptslug.com/script/midnight-in-paris-2011) (PDF) | — |
| 84 | Moneyball / Человек, который изменил всё | 2011 | Aaron Sorkin and Steven Zaillian | драма | диалоги, цифры | [да](https://imsdb.com/scripts/Moneyball.html) | [да](https://www.scriptslug.com/script/moneyball-2011) (PDF) | да |
| 85 | The Artist / Артист | 2011 | Michel Hazanavicius | комедия | немое кино | [да](https://imsdb.com/scripts/Artist,-The.html) | [да](https://www.scriptslug.com/script/the-artist-2011) (PDF) | — |
| 86 | Argo / Операция «Арго» | 2012 | Chris Terrio | триллер | структура | [да](https://imsdb.com/scripts/Argo.html) | [да](https://www.scriptslug.com/script/argo-2012) (PDF) | — |
| 87 | Lincoln / Линкольн | 2012 | Tony Kushner | драма | речь | [да](https://imsdb.com/scripts/Lincoln.html) | [да](https://www.scriptslug.com/script/lincoln-2012) (PDF) | — |
| 88 | Gravity / Гравитация | 2013 | Alfonso Cuarón and Jonás Cuarón | sci-fi | минимум диалогов | [да](https://imsdb.com/scripts/Gravity.html) | [да](https://www.scriptslug.com/script/gravity-2013) (PDF) | — |
| 89 | Her / Она | 2013 | Spike Jonze | драма | диалог на одном голосе | [да](https://imsdb.com/scripts/Her.html) | [да](https://www.scriptslug.com/script/her-2013) (PDF) | да |
| 90 | The Wolf of Wall Street / Волк с Уолл-стрит | 2013 | Terence Winter | комедия/драма | монолог, темп | [да](https://imsdb.com/scripts/Wolf-of-Wall-Street,-The.html) | [да](https://www.scriptslug.com/script/the-wolf-of-wall-street-2013) (PDF) | — |
| 91 | Birdman or (The Unexpected Virtue of Ignorance) / Бёрдмэн | 2014 | Alejandro G. Iñárritu, Alexander Dinelaris, Armando Bo, and Nicolás Giacobone | драма | ритм одной съёмки | [да](https://imsdb.com/scripts/Birdman.html) | [да](https://www.scriptslug.com/script/birdman-or-the-unexpected-virtue-of-ignorance-2014) (PDF) | да |
| 92 | Boyhood / Детство | 2014 | Richard Linklater | драма | время как структура | [да](https://imsdb.com/scripts/Boyhood.html) | [да](https://www.scriptslug.com/script/boyhood-2014) (PDF) | — |
| 93 | Ex Machina / Из машины | 2014 | Alex Garland | sci-fi | диалог-допрос | [да](https://imsdb.com/scripts/Ex-Machina.html) | [да](https://www.scriptslug.com/script/ex-machina-2014) (PDF) | — |
| 94 | Gone Girl / Исчезнувшая | 2014 | Gillian Flynn | триллер | ненадёжный рассказчик | — | [да](https://www.scriptslug.com/script/gone-girl-2014) (PDF) | — |
| 95 | Nightcrawler / Ночной рыбак | 2014 | Dan Gilroy | триллер | рост персонажа | — | [да](https://www.scriptslug.com/script/nightcrawler-2014) (PDF) | — |
| 96 | The Imitation Game / Игра в имитацию | 2014 | Graham Moore | биография | структура | — | [да](https://www.scriptslug.com/script/the-imitation-game-2014) (PDF) | — |
| 97 | Whiplash / Одержимость | 2014 | Damien Chazelle | драма | конфликт учитель-ученик | [да](https://imsdb.com/scripts/Whiplash.html) | [да](https://www.scriptslug.com/script/whiplash-2014) (PDF) | да |
| 98 | Inside Out / Головоломка | 2015 | Pete Docter, Meg LeFauve, and Josh Cooley | анимация | абстрактная арка | — | [да](https://www.scriptslug.com/script/inside-out-2015) (PDF) | да |
| 99 | Mad Max: Fury Road / Безумный Макс: Дорога ярости | 2015 | George Miller, Brendan McCarthy, and Nick Lathouris | боевик | минимум диалогов | — | [да](https://www.scriptslug.com/script/mad-max-fury-road-2015) (PDF) | да |
| 100 | Spotlight / Спотлайт | 2015 | Josh Singer and Tom McCarthy | драма | ансамбль, расследование | — | [да](https://www.scriptslug.com/script/spotlight-2015) (PDF) | да |
| 101 | The Big Short / Игра на понижение | 2015 | Adam McKay | драма | объяснение сложного | — | [да](https://www.scriptslug.com/script/the-big-short-2015) (PDF) | да |
| 102 | Arrival / Прибытие | 2016 | Eric Heisserer | sci-fi | нелинейность | — | [да](https://www.scriptslug.com/script/arrival-2016) (PDF) | да (PDF-скан, текста нет) |
| 103 | Hell or High Water / Ограбление по-техасски | 2016 | Taylor Sheridan | криминал | структура | — | [да](https://www.scriptslug.com/script/hell-or-high-water-2016) (PDF) | — |
| 104 | La La Land / Ла-Ла Ленд | 2016 | Damien Chazelle | мюзикл | структура песни | [да](https://imsdb.com/scripts/La-La-Land.html) | [да](https://www.scriptslug.com/script/la-la-land-2016) (PDF) | — |
| 105 | Manchester by the Sea / Манчестер у моря | 2016 | Kenneth Lonergan | драма | подтекст | — | [да](https://www.scriptslug.com/script/manchester-by-the-sea-2016) | — |
| 106 | Moonlight / Лунный свет | 2016 | Barry Jenkins and Tarell Alvin McCraney | драма | три акта одного героя | — | [да](https://www.scriptslug.com/script/moonlight-2016) (PDF) | — |
| 107 | Call Me by Your Name / Зови меня своим именем | 2017 | James Ivory | драма | адаптация | — | [да](https://www.scriptslug.com/script/call-me-by-your-name-2017) (PDF) | — |
| 108 | Get Out / Прочь | 2017 | Jordan Peele | хоррор | социальная метафора | [да](https://imsdb.com/scripts/Get-Out.html) | [да](https://www.scriptslug.com/script/get-out-2017) (PDF) | — |
| 109 | Lady Bird / Леди Бёрд | 2017 | Greta Gerwig | драма | бытовые сцены | — | [да](https://www.scriptslug.com/script/lady-bird-2017) (PDF) | — |
| 110 | The Shape of Water / Форма воды | 2017 | Guillermo del Toro and Vanessa Taylor | фэнтези | сказочная структура | — | [да](https://www.scriptslug.com/script/the-shape-of-water-2017) (PDF) | — |
| 111 | Three Billboards Outside Ebbing, Missouri / Три билборда за пределами Эббинга | 2017 | Martin McDonagh | драма | юмор и боль | — | [да](https://www.scriptslug.com/script/three-billboards-outside-ebbing-missouri-2017) (PDF) | — |
| 112 | Joker / Джокер | 2019 | Todd Phillips and Scott Silver | драма | арка персонажа | [да](https://imsdb.com/scripts/Joker.html) | [да](https://www.scriptslug.com/script/joker-2019) (PDF) | да |
| 113 | Knives Out / Достать ножи | 2019 | Rian Johnson | детектив | структура детектива | — | [да](https://www.scriptslug.com/script/knives-out-2019) (PDF) | — |
| 114 | Parasite / Паразиты | 2019 | Bong Joon-ho and Jin Won Han | драма/триллер | смена жанра | — | [да](https://www.scriptslug.com/script/parasite-2019) (PDF) | да |
| 115 | Nomadland / Кочевница | 2020 | Chloé Zhao | драма | документальный стиль | — | [да](https://www.scriptslug.com/script/nomadland-2020) (PDF) | да |
| 116 | Dune / Дюна | 2021 | Jon Spaihts, Denis Villeneuve, Eric Roth, and Frank Herbert | sci-fi | экспозиция, мир | [да](https://imsdb.com/scripts/Dune.html) | [да](https://www.scriptslug.com/script/dune-2021) (PDF) | — |
| 117 | Everything Everywhere All at Once / Всё везде и сразу | 2022 | Dan Kwan and Daniel Scheinert | комедия | мультивселенная | — | [да](https://www.scriptslug.com/script/everything-everywhere-all-at-once-2022) (PDF) | да |
| 118 | Anatomy of a Fall / Анатомия падения | 2023 | Justine Triet and Arthur Harari | драма | судебный детектив | — | [да](https://www.scriptslug.com/script/anatomy-of-a-fall-2023) (PDF) | да |
| 119 | Killers of the Flower Moon / Убийцы цветочной луны | 2023 | Eric Roth, Martin Scorsese, and David Grann | криминал | документальные детали | [да](https://imsdb.com/scripts/Killers-of-the-Flower-Moon.html) | [да](https://www.scriptslug.com/script/killers-of-the-flower-moon-2023) (PDF) | — |
| 120 | Oppenheimer / Оппенгеймер | 2023 | Christopher Nolan | драма | нелинейность | [да](https://imsdb.com/scripts/Oppenheimer.html) | [да](https://www.scriptslug.com/script/oppenheimer-2023) (PDF) | да |
| 121 | Past Lives / Прошлые жизни | 2023 | Celine Song | драма | подтекст | — | [да](https://www.scriptslug.com/script/past-lives-2023) (PDF) | — |
| 122 | The Holdovers / Оставшиеся | 2023 | David Hemingson | комедия | ансамбль | [да](https://imsdb.com/scripts/Holdovers,-The.html) | [да](https://www.scriptslug.com/script/the-holdovers-2023) (PDF) | — |
| 123 | A Complete Unknown / Никто не знает | 2024 | James Mangold, Jay Cocks, and Elijah Wald | биография | структура | — | [да](https://www.scriptslug.com/script/a-complete-unknown-2024) (PDF) | — |
| 124 | Anora / Анора | 2024 | Sean Baker | драма | комедия-драма | [да](https://imsdb.com/scripts/Anora.html) | [да](https://www.scriptslug.com/script/anora-2024) (PDF) | да |
| 125 | Conclave / Конклав | 2024 | Peter Straughan and Robert Harris | триллер | диалог, интриги | — | [да](https://www.scriptslug.com/script/conclave-2024) (PDF) | да |
| 126 | Emilia Pérez / Эмилия Перес | 2024 | Jacques Audiard, Thomas Bidegain, and Léa Mysius | мюзикл | жанр | — | [да](https://www.scriptslug.com/script/emilia-perez-2024) (PDF) | — |
| 127 | The Brutalist / Бруталист | 2024 | Brady Corbet and Mona Fastvold | драма | эпос | [да](https://imsdb.com/scripts/Brutalist,-The.html) | [да](https://www.scriptslug.com/script/the-brutalist-2024) (PDF) | — |
| 128 | The Substance / Субстанция | 2024 | Coralie Fargeat | хоррор | метафора, структура | [да](https://imsdb.com/scripts/Substance,-The.html) | [да](https://www.scriptslug.com/script/the-substance-2024) (PDF) | — |
| 129 | Hamnet / Гамнет | 2025 | Chloé Zhao and Maggie O'Farrell | драма | структура | — | [да](https://www.scriptslug.com/script/hamnet-2025) (PDF) | — |
| 130 | Marty Supreme / Марти Суприм | 2025 | Ronald Bronstein and Josh Safdie | драма | ритм | — | [да](https://www.scriptslug.com/script/marty-supreme-2025) (PDF) | — |
| 131 | One Battle After Another / Одна битва за другой | 2025 | Paul Thomas Anderson | криминал | структура | — | [да](https://www.scriptslug.com/script/one-battle-after-another-2025) | — |
| 132 | Sentimental Value / Сентиментальная ценность | 2025 | Eskil Vogt and Joachim Trier | драма | структура | — | [да](https://www.scriptslug.com/script/sentimental-value-2025) (PDF) | — |
| 133 | Sinners / Грешники | 2025 | Ryan Coogler | хоррор | жанровое смешение | — | [да](https://www.scriptslug.com/script/sinners-2025) (PDF) | да |

## 3. Без проверенной ссылки (43)

Сценаристы в этих строках не сверены: указаны по памяти либо не указаны. Статус — по результатам проверки.

| Фильм / сериал | Год | Жанр | За что изучать | Статус |
|---|---|---|---|---|
| Some Like It Hot / Некоторые любят погорячее | 1959 | комедия | ритм реплик, двойная интрига | IMSDb: страница-заглушка, текста нет; PDF не найден |
| Sunset Boulevard / Бульвар Сансет | 1950 | нуар/драма | рассказ от конца, закадровый голос | IMSDb: страница-заглушка, текста нет; PDF не найден |
| Dr. Strangelove / Доктор Стрейнджлав | 1964 | сатира | комедия абсурда | IMSDb: страница-заглушка, текста нет; PDF не найден |
| Dune: Part Two / Дюна: Часть вторая | 2024 | sci-fi | эпос | IMSDb: страница-заглушка, текста нет; PDF не найден |
| Slow Horses / Медленные лошади | 2022 | шпионский | ансамбль | нет в открытом доступе (не найдено или не проверено) |
| The Sopranos / Клан Сопрано | 1999 | драма/криминал | пилот: мир семьи и двойственность героя | нет в открытом доступе (не найдено или не проверено) |
| Breaking Bad / Во все тяжкие | 2008 | драма/криминал | пилот: завязка и смена героя | нет в открытом доступе (не найдено или не проверено) |
| Mad Men / Безумцы | 2007 | драма | пилот: экспозиция через стиль | нет в открытом доступе (не найдено или не проверено) |
| The Wire / Прослушка | 2002 | криминал | полицейский детектив, реализм | нет в открытом доступе (не найдено или не проверено) |
| Succession / Наследники | 2018 | драма | диалог сильных персонажей | нет в открытом доступе (не найдено или не проверено) |
| Fleabag / Дрянь | 2016 | комедия | обращение к зрителю | нет в открытом доступе (не найдено или не проверено) |
| Chernobyl / Чернобыль | 2019 | драма | документальный подход | нет в открытом доступе (не найдено или не проверено) |
| True Detective / Настоящий детектив | 2014 | детектив | диалоги, структура сезона | нет в открытом доступе (не найдено или не проверено) |
| Game of Thrones / Игра престолов | 2011 | фэнтези | пилот: много персонажей | нет в открытом доступе (не найдено или не проверено) |
| Lost / Остаться в живых | 2004 | драма | тайна, пилот | IMSDb: страница-заглушка, текста нет; PDF не найден |
| Fargo / Фарго (сериал) | 2014 | криминал | антология | нет в открытом доступе (не найдено или не проверено) |
| The Bear / Медведь | 2022 | драма | ритм диалога | нет в открытом доступе (не найдено или не проверено) |
| Severance / Разделение | 2022 | драма/sci-fi | экспозиция через вопрос | нет в открытом доступе (не найдено или не проверено) |
| The White Lotus / Белый лотос | 2021 | комедия/драма | сатира | нет в открытом доступе (не найдено или не проверено) |
| Euphoria / Эйфория | 2019 | драма | сцены-монологи | нет в открытом доступе (не найдено или не проверено) |
| The Office / Офис | 2001 | комедия | мокьюментари | нет в открытом доступе (не найдено или не проверено) |
| Friends / Друзья | 1994 | комедия | пилот: ансамбль | IMSDb: страница-заглушка, текста нет; PDF не найден |
| Seinfeld / Сайнфелд | 1989 | комедия | структура «ни о чём» | IMSDb: страница-заглушка, текста нет; PDF не найден |
| The Big Bang Theory / Теория большого взрыва | 2007 | комедия | сетапы | нет в открытом доступе (не найдено или не проверено) |
| Rick and Morty / Рик и Морти | 2013 | анимация | спец-структура | нет в открытом доступе (не найдено или не проверено) |
| South Park / Южный парк | 1997 | анимация | скорость, сатира | IMSDb: страница-заглушка, текста нет; PDF не найден |
| The Queen's Gambit / Ход королевы | 2020 | драма | структура | нет в открытом доступе (не найдено или не проверено) |
| House of the Dragon / Дом дракона | 2022 | фэнтези | структура | нет в открытом доступе (не найдено или не проверено) |
| The Last of Us / Одни из нас | 2023 | драма | адаптация игры | нет в открытом доступе (не найдено или не проверено) |
| Better Call Saul / Лучше звоните Солу | 2015 | драма | структура | нет в открытом доступе (не найдено или не проверено) |
| Ted Lasso / Тед Лассо | 2020 | комедия | арки | нет в открытом доступе (не найдено или не проверено) |
| Peaky Blinders / Острые козырьки | 2013 | драма | пилот | нет в открытом доступе (не найдено или не проверено) |
| Sherlock / Шерлок | 2010 | детектив | диалог | нет в открытом доступе (не найдено или не проверено) |
| Black Mirror / Чёрное зеркало | 2011 | антология |  | нет в открытом доступе (не найдено или не проверено) |
| Stranger Things / Очень странные дела | 2016 | sci-fi | пилот | нет в открытом доступе (не найдено или не проверено) |
| Dark / Тёмный | 2017 | sci-fi | сложная структура | нет в открытом доступе (не найдено или не проверено) |
| Shogun / Сёгун | 2024 | драма | исторический | нет в открытом доступе (не найдено или не проверено) |
| Mindhunter / Охотник за разумом | 2017 | триллер | диалог-допросы | нет в открытом доступе (не найдено или не проверено) |
| Killing Eve / Убивая Еву | 2018 | триллер | диалог | нет в открытом доступе (не найдено или не проверено) |
| Twin Peaks / Твин Пикс | 1990 | драма | пилот | нет в открытом доступе (не найдено или не проверено) |
| The Crown / Корона | 2016 | драма | исторический | нет в открытом доступе (не найдено или не проверено) |
| Mr. Robot / Мистер Робот | 2015 | триллер | ненадёжный рассказчик | нет в открытом доступе (не найдено или не проверено) |
| Westworld / Мир Дикого Запада | 2016 | sci-fi | структура | нет в открытом доступе (не найдено или не проверено) |

## 4. Оскар за лучший сценарий, 2000–2026 (по Википедии)

Номер церемонии, год церемонии. Строки, помеченные «по памяти», не выпали из извлечения Википедии и не сверены; их проверить перед использованием.

| Церемония | Год | Оригинальный сценарий | Адаптированный сценарий |
|---|---|---|---|
| 72 | 2000 | American Beauty — Alan Ball | The Cider House Rules — John Irving |
| 73 | 2001 | Almost Famous — Cameron Crowe | Traffic — Stephen Gaghan |
| 74 | 2002 | Gosford Park — Julian Fellowes | A Beautiful Mind — Akiva Goldsman |
| 75 | 2003 | Talk to Her — Pedro Almodóvar | The Pianist — Ronald Harwood (по памяти) |
| 76 | 2004 | Lost in Translation — Sofia Coppola | The Lord of the Rings: The Return of the King — Fran Walsh, Philippa Boyens, Peter Jackson |
| 77 | 2005 | Eternal Sunshine of the Spotless Mind — Charlie Kaufman, Michel Gondry, Pierre Bismuth | Sideways — Alexander Payne, Jim Taylor |
| 78 | 2006 | Crash — Paul Haggis, Bobby Moresco | Brokeback Mountain — Larry McMurtry, Diana Ossana |
| 79 | 2007 | Little Miss Sunshine — Michael Arndt | The Departed — William Monahan |
| 80 | 2008 | Juno — Diablo Cody | No Country for Old Men — Joel and Ethan Coen |
| 81 | 2009 | Milk — Dustin Lance Black | Slumdog Millionaire — Simon Beaufoy (по памяти) |
| 82 | 2010 | The Hurt Locker — Mark Boal | Precious — Geoffrey S. Fletcher |
| 83 | 2011 | The King's Speech — David Seidler (по памяти) | The Social Network — Aaron Sorkin |
| 84 | 2012 | Midnight in Paris — Woody Allen | The Descendants — Alexander Payne, Nat Faxon, Jim Rash |
| 85 | 2013 | Django Unchained — Quentin Tarantino | Argo — Chris Terrio (по памяти) |
| 86 | 2014 | Her — Spike Jonze | 12 Years a Slave — John Ridley |
| 87 | 2015 | Birdman — Alejandro G. Iñárritu, Nicolás Giacobone, Alexander Dinelaris, Armando Bo | The Imitation Game — Graham Moore |
| 88 | 2016 | Spotlight — Tom McCarthy, Josh Singer | The Big Short — Adam McKay, Charles Randolph |
| 89 | 2017 | Manchester by the Sea — Kenneth Lonergan | Moonlight — Barry Jenkins, Tarell Alvin McCraney |
| 90 | 2018 | Get Out — Jordan Peele | Call Me by Your Name — James Ivory |
| 91 | 2019 | Green Book — Nick Vallelonga, Brian Hayes Currie, Peter Farrelly (по памяти) | BlacKkKlansman — Spike Lee, Kevin Willmott, Charlie Wachtel, David Rabinowitz |
| 92 | 2020 | Parasite — Bong Joon-ho, Han Jin-won | Jojo Rabbit — Taika Waititi |
| 93 | 2021 | Promising Young Woman — Emerald Fennell | The Father — Florian Zeller, Christopher Hampton |
| 94 | 2022 | Belfast — Kenneth Branagh | CODA — Sian Heder |
| 95 | 2023 | Everything Everywhere All at Once — Daniels | Women Talking — Sarah Polley |
| 96 | 2024 | Anatomy of a Fall — Justine Triet, Arthur Harari | American Fiction — Cord Jefferson |
| 97 | 2025 | Anora — Sean Baker | Conclave — Peter Straughan (по памяти) |
| 98 | 2026 | Sinners — Ryan Coogler | One Battle After Another — Paul Thomas Anderson |

## 5. Русскоязычные тексты

Скачано пять PDF с текстовым слоем (`BIBLIOTEKA/scenarii/ru/`). Ссылки проверены, PDF открываются. Права: первоисточник публикации указан на сайте; пять позиций, в которых первоисточник не назван, помечены.

| Текст | Сценаристы (по сайту) | Первоисточник публикации по сайту | Статус |
|---|---|---|---|
| Горько! (2013), сценарий | Алексей Казаков, Николай Куликов, Жора Крыжовников | t.me/bazelevs_official/61 (продюсер) | скачан |
| Самый лучший день, сценарий | Жора Крыжовников, Алексей Казаков | t.me/bazelevs_official/271 (продюсер) | скачан |
| Притяжение, сценарий | не указано | t.me/artpicturesrus/348 (продюсер) | скачан |
| Эпидемия, пилотная серия | Роман Кантор | не указан | скачан, права не проверены |
| Перевал Дятлова, пилотная серия | Илья Куликов | не указан | скачан, права не проверены |

Не скачаны: русские переводы «Паразитов» и «Прочь» на Kinodramaturg (переводы сайта, права не подтверждены). Русские пилоты Мистера Робота на том же сайте — тот же случай.

Советская классика в открытом доступе легально не найдена (см. раздел 1).

## 6. Что скачано и где лежит

- `BIBLIOTEKA/scenarii/en/`: 51 PDF и 51 текстовых файлов, объём 61.8 МБ. Один PDF без текстового слоя (скан): Arrival (2016); его IMSDb-страница — заглушка. OCR не делался.
- Для Alien (1979), Forrest Gump (1994) и Toy Story (1995) PDF с ScriptSlug оказался сканом без текста. Текст взят с IMSDb отдельными файлами `… — IMSDb.txt`. PDF оставлены рядом.
- `BIBLIOTEKA/scenarii/ru/`: 5 PDF и 5 текстовых файлов, объём 3.4 МБ.
- Текстовые файлы: шапка (название, год, сценарист, источник, URL, дата скачивания, примечание), затем текст. Для IMSDb текст берётся из `<pre>`, для PDF — `pdftotext -layout`.
- Качество текста: PDF ScriptSlug у Casablanca — OCR со старой машинописи, есть шум в тексте. Остальные — в основном чистые.
- Скрипт: `BIBLIOTEKA/scenarii/skachat_scenarii.py` (только стандартная библиотека). Запуск из папки BIBLIOTEKA/scenarii: `python3 -I skachat_scenarii.py --spisok spisok-start.json --kuda en/`. Русские: `--spisok spisok-ru.json --kuda ru/`.
- Проблемы, найденные по ходу: три IMSDb-страницы оказались заглушками (Some Like It Hot, Dr. Strangelove, Seinfeld) и из списка убраны; скрипт теперь не сохраняет файлы без текста. У ScriptSlug-PDF проверка только по сигнатуре; текстовый слой проверяется после скачивания (короткий текст помечается как скан).

## 7. Как учиться по сценарию

1. **Целиком, за один присест.** Прочитать от начала до конца за 1–2 часа, без остановок, без заметок и без разбора. Задача — почувствовать ритм и где затянуло. Фильм не смотреть до конца этого шага.
2. **Разметка актов и битов.** Второй проход с карандашом: где экспозиция кончается и начинается конфликт (обычно к 10–12 страницам из 110), где точка середины, где «всё потеряно», где финал. Бит — изменение состояния героя: что он знал или хотел, и что стало иначе. Для PDF помнить: страница ≈ 1 минута экрана, это грубая карта хронометража.
3. **Карточки сцен.** По одной карточке на каждую сцену, три строки: чего хочет герой в сцене; что ему мешает; чем кончилась сцена (что сдвинулось). Для 100–120 сцен карточек будет 100–120. Лишние сцены видны сразу: в них ничего не меняется.
4. **Сравнение с фильмом по таймкодам.** Фильм ставится на паузу на каждой спорной карточке. Отметить: вырезано, добавлено, переписано на съёмке, сыграно иначе. Минимум пять мест сравнить дословно. Особенно важно, что в фильме режиссёр нашёл лучше текста, и где текст был сильнее.
5. **Важно про источник.** IMSDb и часть PDF — транскрипции чужой редакции, а не финальный фильм. Для сравнения хронометража опираться на фильм, а не на текст.
6. **Ритм чтения.** Три сценария одного жанра подряд, затем один из другого жанра. Вести журнал: что понравилось, что вызвало скуку, на каком бите.

## 8. Десять сценариев на первый месяц

Порядок — от простого к сложному. Все десять есть в стартовом наборе и скачаны.

| № | Сценарий | Зачем именно этот |
|---|---|---|
| 1 | Casablanca (1942) | Одна локация, экспозиция через разговоры, подтекст вместо объяснений. Видно, как работает сцена без экшена. Минус: скан-OCR, читать терпеливо. |
| 2 | Chinatown (1974) | Структура детектива: тайна, ложные следы, финальный поворот. Учит обещать зрителю и потом платить по обещанию. |
| 3 | Taxi Driver (1976) | Внутренний монолог и арка персонажа в действии. Как ведётся герой, которому не с кем говорить. |
| 4 | Lost in Translation (2003) | Почти без сюжетных событий, держится на подтексте и паузах. Учит, как строить сцену вокруг недосказанного. |
| 5 | Eternal Sunshine of the Spotless Mind (2004) | Нелинейная структура, в которой логика памяти и логика сюжета совпадают. Разбор того, как порядок сцен становится смыслом. |
| 6 | Little Miss Sunshine (2006) | Ансамбль и структура «дорога»: у каждого персонажа своя арка, внешняя цель нужна, чтобы их свести. |
| 7 | Good Will Hunting (1997) | Диалог на сильных сценах и арка «учитель–ученик». Учит, как диалог несёт конфликт, а не информацию. |
| 8 | The Social Network (2010) | Очень быстрый диалог и нелинейность через два допроса. Оскар за адаптированный сценарий (83-я церемония). Учит темпу реплик. |
| 9 | Toy Story (1995) | Групповой герой и подготовка (setup) и выплата (payoff) в детском фильме. Очень чистая структура, удобно сверять с картой битов. |
| 10 | Parasite (2019) | Смена жанра по актам и выстроенный поворот в середине. Оскар за оригинальный сценарий (92-я церемония). Учит, как менять рамку, не теряя логики. |

## Что не удалось проверить или не сделано

- Сайты Script Lab, Scripts on Screen (scriptsonscreen.com), WGF-каталог и bbc.co.uk через WebFetch из среды не открылись (curl у BBC отдаёт 200). Ссылки на эти сайты — со слов поиска или страниц, не открытых полностью.
- IMDb Top 250 в этом прогоне не сверялся.
- Из 176 позиций 35 без проверенной ссылки (раздел 3).
- Сценарии сериалов: из ТВ в открытом доступе по проверке не найдено ни одного текста: IMSDb-страницы Friends, Lost, Seinfeld, South Park — заглушки. Все четыре IMSDb-страницы ТВ-транскриптов (Friends, Lost, Seinfeld, South Park) оказались заглушками без текста. Остальные пилоты (Sopranos, Breaking Bad, Mad Men, The Wire и др.) не найдены.
- Тексты скачаны без проверки прав, кроме указанных публикаций. Перед использованием в учебных материалах — решить вопрос с правообладателями.

