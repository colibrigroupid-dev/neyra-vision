#!/usr/bin/env python3
"""
fountain2html.py — сценарий в формате Fountain → HTML в голливудской вёрстке → (по желанию) PDF.

Только стандартная библиотека Python 3. Кириллица работает везде: шрифт Courier Prime,
если установлен, иначе Courier New (есть на Mac и Windows).

Использование:
    python3 fountain2html.py draft-01.fountain                 # создаст draft-01.html
    python3 fountain2html.py draft-01.fountain --pdf           # плюс draft-01.pdf через Chrome/Edge
    python3 fountain2html.py draft-01.fountain -o out.html
    python3 fountain2html.py draft-01.fountain --a4            # лист A4 вместо US Letter

Если --pdf не нашёл Chrome/Edge: откройте HTML в любом браузере → Печать → Сохранить как PDF.
"""
import argparse, html, os, re, shutil, subprocess, sys, platform

# Русские и английские начала заголовков сцен
SCENE_PREFIXES = ("INT", "EXT", "EST", "INT./EXT", "INT/EXT", "I/E",
                  "ИНТ", "НАТ", "ИНТ./НАТ", "ИНТ/НАТ", "ЭКСТ")

def is_scene_heading(line):
    s = line.strip()
    if s.startswith(".") and not s.startswith(".."):
        return True
    up = s.upper()
    for p in SCENE_PREFIXES:
        if up.startswith(p + ".") or up.startswith(p + " "):
            return True
    return False

def is_upper(s):
    letters = [c for c in s if c.isalpha()]
    return bool(letters) and all(c.isupper() for c in letters)

def is_transition(line):
    s = line.strip()
    if s.startswith(">") and not s.endswith("<"):
        return True
    return is_upper(s) and (s.endswith("TO:") or s.endswith("ИЗ:") or s.endswith("В:"))

def is_centered(line):
    s = line.strip()
    return s.startswith(">") and s.endswith("<")

def is_character(line, next_line):
    s = line.strip()
    if not s or next_line is None or not next_line.strip():
        return False
    if s.startswith("@"):
        return True
    if s.startswith("!") or s.startswith("."):
        return False
    core = re.sub(r"\(.*?\)", "", s).replace("^", "").strip()
    return is_upper(core)

def inline(text):
    t = html.escape(text)
    t = re.sub(r"\[\[.*?\]\]", "", t)                     # заметки не печатаются
    t = re.sub(r"\*\*\*(.+?)\*\*\*", r"<b><i>\1</i></b>", t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"\*(.+?)\*", r"<i>\1</i>", t)
    t = re.sub(r"_(.+?)_", r"<u>\1</u>", t)
    return t

def strip_boneyard(text):
    return re.sub(r"/\*.*?\*/", "", text, flags=re.S)

def parse_title_page(lines):
    """Возвращает (dict, остаток строк). Титул — блок 'Ключ: значение' в самом начале."""
    meta, i = {}, 0
    key = None
    if not lines or ":" not in lines[0] or is_scene_heading(lines[0]):
        return meta, lines
    while i < len(lines) and lines[i].strip():
        ln = lines[i]
        m = re.match(r"^([A-Za-zА-Яа-яЁё ]+):\s*(.*)$", ln)
        if m and not ln.startswith((" ", "\t")):
            key = m.group(1).strip().lower()
            meta[key] = m.group(2).strip()
        elif key and ln.startswith((" ", "\t")):
            meta[key] = (meta[key] + "\n" + ln.strip()).strip()
        else:
            return {}, lines
        i += 1
    return meta, lines[i+1:]

def parse(text):
    text = strip_boneyard(text.replace("\r\n", "\n").replace("\r", "\n"))
    lines = text.split("\n")
    meta, lines = parse_title_page(lines)
    out = []  # список (тип, html)
    i, n = 0, len(lines)
    def nxt(k): return lines[k] if k < n else None
    while i < n:
        raw = lines[i]
        s = raw.strip()
        if not s:
            i += 1; continue
        if s.startswith("#"):                      # секция — не печатается
            i += 1; continue
        if s.startswith("=") and not s.startswith("==="):   # синопсис — не печатается
            i += 1; continue
        if s == "===":
            out.append(("pagebreak", "")); i += 1; continue
        prev_blank = (i == 0) or not lines[i-1].strip()
        if prev_blank and is_scene_heading(raw):
            t = s[1:] if s.startswith(".") else s
            out.append(("scene", inline(t.upper() if not s.startswith(".") else t))); i += 1; continue
        if is_centered(raw):
            out.append(("centered", inline(s[1:-1].strip()))); i += 1; continue
        if prev_blank and is_transition(raw):
            t = s[1:].strip() if s.startswith(">") else s
            out.append(("transition", inline(t))); i += 1; continue
        if prev_blank and is_character(raw, nxt(i+1)):
            name = s[1:] if s.startswith("@") else s
            dual = name.endswith("^")
            name = name.rstrip("^").strip()
            block = [("character", inline(name))]
            i += 1
            while i < n and lines[i].strip():
                d = lines[i].strip()
                if d.endswith("^"):            # знак двойного диалога на реплике — тоже принимаем
                    dual = True; d = d.rstrip("^").strip()
                if d.startswith("(") and d.endswith(")"):
                    block.append(("parenthetical", inline(d)))
                elif d.startswith("~"):
                    block.append(("lyrics", inline(d[1:].strip())))
                else:
                    block.append(("dialogue", inline(d)))
                i += 1
            out.append(("dialogue-block", (dual, block))); continue
        if s.startswith("~"):                     # песня / стихи вне диалога
            out.append(("lyrics", inline(s.strip("~").strip()))); i += 1; continue
        # действие: собираем до пустой строки, сохраняем переносы
        buf = []
        while i < n and lines[i].strip():
            a = lines[i]
            if a.strip().startswith("!"):
                a = a.replace("!", "", 1)
            buf.append(inline(a.rstrip()))
            i += 1
        out.append(("action", "<br>".join(buf)))
    return meta, out

CSS = """
@page { size: %(size)s; margin: 1in 1in 1in 1.5in; }
html, body { margin: 0; padding: 0; background: #fff; color: #000; }
body { font-family: "Courier Prime", "Courier New", Courier, monospace; font-size: 12pt; line-height: 1.0; }
.page { max-width: 6in; margin: 0 auto; padding: 1in 0; }
@media screen { body { background: #e8e8e8; } .page { background: #fff; padding: 1in 1in 1in 1.5in; max-width: 6in; margin: 24px auto; box-shadow: 0 2px 8px rgba(0,0,0,.2); } }
p { margin: 0; white-space: pre-wrap; }
.scene { text-transform: none; font-weight: normal; margin-top: 2em; margin-bottom: 1em; }
.action { margin-bottom: 1em; }
.dialogue-block { margin-bottom: 1em; page-break-inside: avoid; }
.character { margin-left: 2.2in; }
.parenthetical { margin-left: 1.6in; width: 2.0in; }
.dialogue { margin-left: 1.0in; width: 3.5in; }
.lyrics { margin-left: 1.0in; width: 3.5in; font-style: italic; }
.transition { text-align: right; margin: 1em 0; }
.centered { text-align: center; margin: 1em 0; }
.pagebreak { page-break-after: always; }
.dual { display: flex; gap: .3in; }
.dual .dialogue-block { flex: 1; }
.dual .character { margin-left: .9in; }
.dual .dialogue, .dual .parenthetical, .dual .lyrics { margin-left: 0; width: auto; }
.title-page { page-break-after: always; height: 8.5in; position: relative; text-align: center; }
.title-page .title { position: absolute; top: 3in; left: 0; right: 0; text-transform: uppercase; }
.title-page .credit { position: absolute; top: 3.6in; left: 0; right: 0; }
.title-page .author { position: absolute; top: 4.0in; left: 0; right: 0; }
.title-page .meta { position: absolute; bottom: 0; left: 0; text-align: left; white-space: pre-wrap; }
.title-page .right { position: absolute; bottom: 0; right: 0; text-align: right; white-space: pre-wrap; }
"""

def render(meta, items, size):
    parts = ['<!doctype html><html lang="ru"><head><meta charset="utf-8">',
             '<title>%s</title>' % html.escape(meta.get("title", "Сценарий")),
             '<style>%s</style></head><body><div class="page">' % (CSS % {"size": size})]
    if meta:
        parts.append('<div class="title-page">')
        parts.append('<p class="title">%s</p>' % inline(meta.get("title", "")))
        if meta.get("credit"): parts.append('<p class="credit">%s</p>' % inline(meta["credit"]))
        if meta.get("author") or meta.get("authors"):
            parts.append('<p class="author">%s</p>' % inline(meta.get("author") or meta.get("authors")))
        left = "\n".join(meta[k] for k in ("contact", "copyright", "notes") if k in meta)
        right = "\n".join(meta[k] for k in ("draft date", "date", "revision") if k in meta)
        if left: parts.append('<p class="meta">%s</p>' % inline(left))
        if right: parts.append('<p class="right">%s</p>' % inline(right))
        parts.append('</div>')
    pending_dual = None
    for kind, val in items:
        if kind == "dialogue-block":
            dual, block = val
            blk = '<div class="dialogue-block">' + "".join('<p class="%s">%s</p>' % (k, v) for k, v in block) + '</div>'
            if dual and pending_dual:
                parts.append('<div class="dual">%s%s</div>' % (pending_dual, blk)); pending_dual = None
            else:
                if pending_dual: parts.append(pending_dual)
                pending_dual = blk
            continue
        if pending_dual:
            parts.append(pending_dual); pending_dual = None
        if kind == "pagebreak":
            parts.append('<div class="pagebreak"></div>')
        else:
            parts.append('<p class="%s">%s</p>' % (kind, val))
    if pending_dual: parts.append(pending_dual)
    parts.append('</div></body></html>')
    return "\n".join(parts)

def find_browser():
    cands = []
    if platform.system() == "Darwin":
        cands = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                 "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                 "/Applications/Chromium.app/Contents/MacOS/Chromium",
                 "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
                 "/Applications/Yandex.app/Contents/MacOS/Yandex"]
    elif platform.system() == "Windows":
        pf = [os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"), os.environ.get("LocalAppData", "")]
        for base in pf:
            cands += [os.path.join(base, r"Google\Chrome\Application\chrome.exe"),
                      os.path.join(base, r"Microsoft\Edge\Application\msedge.exe"),
                      os.path.join(base, r"Yandex\YandexBrowser\Application\browser.exe")]
    for c in cands:
        if c and os.path.exists(c): return c
    for name in ("google-chrome", "chromium", "chromium-browser", "microsoft-edge", "msedge", "chrome"):
        p = shutil.which(name)
        if p: return p
    return None

def to_pdf(html_path, pdf_path):
    b = find_browser()
    if not b:
        print("Chrome/Edge не найден. Откройте HTML в браузере → Печать → Сохранить как PDF.", file=sys.stderr)
        return False
    url = "file://" + os.path.abspath(html_path)
    cmd = [b, "--headless=new", "--disable-gpu", "--no-pdf-header-footer", "--print-to-pdf=" + os.path.abspath(pdf_path), url]
    r = subprocess.run(cmd, capture_output=True, text=True)
    ok = os.path.exists(pdf_path) and os.path.getsize(pdf_path) > 1000
    if not ok:
        print("PDF не собрался. Вывод браузера:\n" + (r.stderr or r.stdout)[-800:], file=sys.stderr)
    return ok

def main():
    ap = argparse.ArgumentParser(description="Fountain → HTML (→ PDF)")
    ap.add_argument("src")
    ap.add_argument("-o", "--out")
    ap.add_argument("--pdf", action="store_true", help="также собрать PDF через Chrome/Edge")
    ap.add_argument("--a4", action="store_true", help="лист A4 (по умолчанию US Letter)")
    a = ap.parse_args()
    with open(a.src, encoding="utf-8-sig") as f:
        text = f.read()
    meta, items = parse(text)
    out = a.out or os.path.splitext(a.src)[0] + ".html"
    with open(out, "w", encoding="utf-8") as f:
        f.write(render(meta, items, "A4" if a.a4 else "Letter"))
    n_scenes = sum(1 for k, _ in items if k == "scene")
    n_dial = sum(1 for k, _ in items if k == "dialogue-block")
    print("HTML: %s  (сцен: %d, реплик: %d)" % (out, n_scenes, n_dial))
    if a.pdf:
        pdf = os.path.splitext(out)[0] + ".pdf"
        if to_pdf(out, pdf):
            print("PDF: %s" % pdf)
        else:
            sys.exit(2)

if __name__ == "__main__":
    main()
