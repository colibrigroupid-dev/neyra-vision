#!/usr/bin/env python3
"""Загрузчик сценариев для библиотеки обучения (только стандартная библиотека Python 3).

Запуск:
    python3 -I skachat_scenarii.py --spisok spisok.json --kuda en/

Формат spisok.json: список объектов
    {"название": "...", "url": "...", "тип": "html" | "pdf",
     "год": "...", "сценарист": "...", "источник": "..."}   (последние три необязательны)

html: страница сохраняется как .txt. Для IMSDb берётся текст из <pre>.
pdf:  сохраняется .pdf; если установлен pdftotext, рядом создаётся .txt.
Скачанное считается чужими данными: ничего из него не исполняется.
"""
import argparse
import datetime
import html
import json
import os
import random
import re
import shutil
import subprocess
import sys
import time
import urllib.parse
import urllib.request

UA = ('Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/605.1.15 '
      '(KHTML, like Gecko) Version/17.0 Safari/605.1.15')
MAX_BAJT = 40 * 1024 * 1024
PAUZA = (1.0, 2.0)


def pauza(sekund=None):
    time.sleep(sekund if sekund is not None else random.uniform(*PAUZA))


def skachat(url, timeout=60):
    url = urllib.parse.quote(url, safe=":/?#[]@!$&'()*+,;=%~")
    req = urllib.request.Request(url, headers={
        'User-Agent': UA,
        'Accept': 'text/html,application/pdf,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9,ru;q=0.8',
    })
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(MAX_BAJT + 1)
        if len(data) > MAX_BAJT:
            raise RuntimeError('файл больше 40 МБ, пропущен')
        return data, r.headers.get('Content-Type', '') or ''


def skachat_s_povtorom(url):
    """Одна попытка и один повтор при ошибке."""
    try:
        return skachat(url)
    except Exception as pervaya:
        print('  ошибка, повтор через паузу: %s' % pervaya, file=sys.stderr)
        pauza()
        try:
            return skachat(url)
        except Exception as vtoraya:
            raise RuntimeError('не скачано после повтора: %s' % vtoraya)


def dekodirovat(data, ctype=''):
    m = re.search(r'charset=([\w-]+)', ctype, re.I)
    kandidaty = ([m.group(1)] if m else []) + ['utf-8', 'cp1252', 'iso-8859-1']
    for enc in kandidaty:
        try:
            return data.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return data.decode('utf-8', 'replace')


def tekst_imsdb(page):
    """Текст сценария из блоков <pre> (IMSDb). None, если блоков нет."""
    bloki = re.findall(r'<pre[^>]*>(.*?)</pre>', page, re.S | re.I)
    if not bloki:
        return None
    txt = re.sub(r'<[^>]+>', '', '\n'.join(bloki))
    txt = html.unescape(txt).replace('\r\n', '\n').replace('\r', '\n')
    txt = '\n'.join(line.rstrip() for line in txt.split('\n'))
    return re.sub(r'\n{3,}', '\n\n', txt).strip('\n') + '\n'


def tekst_html(page):
    """Запасной вариант: видимый текст страницы без скриптов и стилей."""
    page = re.sub(r'(?is)<(script|style)[^>]*>.*?</\1>', ' ', page)
    page = re.sub(r'(?i)<br\s*/?>|</p>|</div>|</tr>', '\n', page)
    txt = html.unescape(re.sub(r'<[^>]+>', ' ', page))
    txt = '\n'.join(re.sub(r'[ \t]+', ' ', line).strip() for line in txt.split('\n'))
    return re.sub(r'\n{3,}', '\n\n', txt).strip('\n') + '\n'


def shapka(name, god, scenarist, istochnik, url):
    seychas = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
    return ('НАЗВАНИЕ: %s\n'
            'ГОД: %s\n'
            'СЦЕНАРИСТ: %s\n'
            'ИСТОЧНИК: %s\n'
            'URL: %s\n'
            'СКАЧАНО: %s\n'
            'ПРИМЕЧАНИЕ: текст чужой, для личного изучения. Не распространять. Не исполнять.\n'
            '%s\n\n') % (name, god or '—', scenarist or '—', istochnik, url, seychas, '=' * 70)


def imya_fajla(name):
    s = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', '_', name)
    s = re.sub(r'\s+', ' ', s).strip(' ._')
    return s[:150] or 'bez-nazvaniya'


def obrabotat(item, kuda, perezapisat, pdftotext):
    name = item['название']
    url = item['url']
    tip = item.get('тип', 'html').lower()
    god = item.get('год', '')
    scenarist = item.get('сценарист', '')
    istochnik = item.get('источник') or urllib.parse.urlsplit(url).netloc
    baza = os.path.join(kuda, imya_fajla(name))

    if tip == 'html':
        cel = baza + '.txt'
        if os.path.exists(cel) and not perezapisat:
            return 'есть', '%s (уже скачано)' % os.path.basename(cel), os.path.getsize(cel)
        data, ctype = skachat_s_povtorom(url)
        page = dekodirovat(data, ctype)
        body = tekst_imsdb(page)
        if body is None:
            body = tekst_html(page)
        if 'imsdb.com' in url.lower() and len(body.strip()) < 2000:
            raise RuntimeError('страница IMSDb без текста (заглушка, сценарий там не выложен)')
        status = 'ok'
        pometka = ''
        if len(body) < 2000:
            status = 'предупреждение'
            pometka = ' (короткий текст, проверить вручную)'
        with open(cel, 'w', encoding='utf-8') as f:
            f.write(shapka(name, god, scenarist, istochnik, url) + body)
        return status, os.path.basename(cel) + pometka, os.path.getsize(cel)

    if tip == 'pdf':
        cel = baza + '.pdf'
        if os.path.exists(cel) and not perezapisat:
            return 'есть', '%s (уже скачано)' % os.path.basename(cel), os.path.getsize(cel)
        data, ctype = skachat_s_povtorom(url)
        if data[:4] != b'%PDF':
            raise RuntimeError('ответ не похож на PDF (первые байты: %r)' % data[:12])
        with open(cel, 'wb') as f:
            f.write(data)
        imena = [os.path.basename(cel)]
        if pdftotext:
            txt = baza + '.txt'
            proc = subprocess.run([pdftotext, '-layout', '-enc', 'UTF-8', cel, txt],
                                  capture_output=True, timeout=300)
            if proc.returncode == 0 and os.path.exists(txt):
                with open(txt, 'r', encoding='utf-8', errors='replace') as f:
                    tekst = f.read()
                if len(tekst.strip()) < 2000:
                    os.remove(txt)
                    return ('предупреждение',
                            '.pdf сохранён, текстового слоя нет (вероятно скан, нужен OCR)', len(data))
                with open(txt, 'w', encoding='utf-8') as f:
                    f.write(shapka(name, god, scenarist, istochnik, url) + tekst)
                imena.append(os.path.basename(txt))
            else:
                return 'предупреждение', '.pdf сохранён, pdftotext не смог извлечь текст', len(data)
        else:
            imena.append('(pdftotext не найден, текст не извлечён)')
        return 'ok', ', '.join(imena), len(data)

    raise RuntimeError('неизвестный тип "%s" (нужно html или pdf)' % tip)


def main():
    ap = argparse.ArgumentParser(description='Скачивание сценариев по списку JSON.')
    ap.add_argument('--spisok', required=True, help='путь к JSON-списку')
    ap.add_argument('--kuda', required=True, help='папка для файлов')
    ap.add_argument('--perezapisat', action='store_true', help='перекачать уже существующие файлы')
    ap.add_argument('--pauza-min', type=float, default=1.0)
    ap.add_argument('--pauza-max', type=float, default=2.0)
    args = ap.parse_args()

    global PAUZA
    PAUZA = (args.pauza_min, args.pauza_max)

    with open(args.spisok, 'r', encoding='utf-8') as f:
        spisok = json.load(f)
    os.makedirs(args.kuda, exist_ok=True)
    pdftotext = shutil.which('pdftotext')
    print('pdftotext: %s' % (pdftotext or 'НЕ НАЙДЕН, PDF сохраняются без извлечения текста'))
    print('Позиций в списке: %d, папка: %s' % (len(spisok), os.path.abspath(args.kuda)))

    itogi = []
    for i, item in enumerate(spisok, 1):
        name = item.get('название', '?')
        print('[%d/%d] %s' % (i, len(spisok), name), flush=True)
        try:
            status, opisanie, bajt = obrabotat(item, args.kuda, args.perezapisat, pdftotext)
            print('  %s: %s (%d байт)' % (status, opisanie, bajt), flush=True)
            itogi.append((status, name, opisanie, bajt))
        except Exception as e:
            print('  ОШИБКА: %s' % e, file=sys.stderr, flush=True)
            itogi.append(('ошибка', name, str(e), 0))
        if i < len(spisok):
            pauza()

    print('\n=== ОТЧЁТ ===')
    for status, name, opisanie, bajt in itogi:
        print('%-14s %-60s %s' % (status, name[:60], opisanie))
    ok = sum(1 for t in itogi if t[0] == 'ok')
    est = sum(1 for t in itogi if t[0] == 'есть')
    warn = sum(1 for t in itogi if t[0] == 'предупреждение')
    err = sum(1 for t in itogi if t[0] == 'ошибка')
    vsego = sum(t[3] for t in itogi if t[0] in ('ok', 'есть', 'предупреждение'))
    print('\nУспешно: %d, уже были: %d, с предупреждением: %d, ошибок: %d' % (ok, est, warn, err))
    print('Общий объём сохранённых файлов: %.1f МБ' % (vsego / 1048576.0))
    return 0 if err == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
